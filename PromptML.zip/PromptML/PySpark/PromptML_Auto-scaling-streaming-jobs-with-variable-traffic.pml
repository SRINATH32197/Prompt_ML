PROBLEM STATEMENT : 

Auto-scaling streaming jobs with variable traffic.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Auto-scaling streaming jobs with variable traffic.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("AutoScalingStreamingJob") \
    .config("spark.sql.shuffle.partitions", "500") \
    .config("spark.streaming.backpressure.enabled", "true") \
    .config("spark.streaming.kafka.maxRatePerPartition", "1000") \
    .config("spark.dynamicAllocation.enabled", "true") \
    .config("spark.dynamicAllocation.minExecutors", "4") \
    .config("spark.dynamicAllocation.maxExecutors", "50") \
    .config("spark.dynamicAllocation.initialExecutors", "10") \
    .config("spark.dynamicAllocation.executorIdleTimeout", "60s") \
    .config("spark.dynamicAllocation.schedulerBacklogTimeout", "1s") \
    .config("spark.dynamicAllocation.sustainedSchedulerBacklogTimeout", "5s") \
    .config("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider") \
    .getOrCreate()

# Read from Kafka
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Stateful aggregation with watermark
aggregated_df = parsed_df \
    .withWatermark("timestamp", "10 minutes") \
    .groupBy("key") \
    .count()

# Write output
aggregated_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/autoscaled_stream_output/") \
    .option("checkpointLocation", "s3://bucket/autoscaled_stream_checkpoint/") \
    .outputMode("append") \
    .start() \
    .awaitTermination()
