PROBLEM STATEMENT : 

Efficiently reading partitioned Parquet files from S3.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Efficiently reading partitioned Parquet files from S3.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("EfficientParquetRead").getOrCreate()

# Define base path and partition filters
base_path = "s3://bucket/path/"
partition_filters = {"year": "2023", "month": "09"}

# Construct path with partition pruning
partition_path = base_path + "/".join([f"{k}={v}" for k, v in partition_filters.items()])

# Read partitioned Parquet efficiently
df = spark.read.parquet(partition_path)

# Optional: cache if reused
df.cache()
