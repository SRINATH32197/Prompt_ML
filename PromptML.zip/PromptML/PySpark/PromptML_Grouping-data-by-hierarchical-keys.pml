PROBLEM STATEMENT : 

Grouping data by hierarchical keys (e.g., region → country → city).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Grouping data by hierarchical keys (e.g., region → country → city).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import sum

spark = SparkSession.builder.appName("HierarchicalGrouping").getOrCreate()

# Load data
df = spark.read.parquet("s3://bucket/location_sales/")

# Group by region → country → city
grouped_df = df.groupBy("region", "country", "city") \
               .agg(sum("sales").alias("total_sales"))

# process grouped_df as needed
