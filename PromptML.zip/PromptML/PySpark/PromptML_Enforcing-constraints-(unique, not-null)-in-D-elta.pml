PROBLEM STATEMENT : 

Enforcing constraints (unique, not null) in D elta.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Enforcing constraints (unique, not null) in D elta.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaConstraintsEnforcement") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Create Delta table with constraints
spark.sql("""
    CREATE TABLE delta.`s3://bucket/constrained_table/` (
        id STRING NOT NULL,
        email STRING NOT NULL,
        created_ts TIMESTAMP,
        CONSTRAINT email_unique UNIQUE (email)
    ) USING DELTA
""")

# Load incoming data
incoming_df = spark.read.parquet("s3://bucket/incoming_data/")

# Write to Delta table with constraints enforced
incoming_df.write \
    .format("delta") \
    .mode("append") \
    .save("s3://bucket/constrained_table/")
```