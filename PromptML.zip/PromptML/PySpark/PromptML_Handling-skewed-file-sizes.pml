PROBLEM STATEMENT : 

Handling skewed file sizes in distributed reads.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling skewed file sizes in distributed reads.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import boto3

spark = SparkSession.builder.appName("SkewedFileSizeRead").getOrCreate()

# S3 config
bucket = "bucket"
prefix = "data/"
s3 = boto3.client("s3")
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

# Collect file sizes
file_info = [(obj["Key"], obj["Size"]) for obj in response.get("Contents", [])
             if not obj["Key"].split("/")[-1].startswith(("_", "."))]

# Sort files by size descending
sorted_files = sorted(file_info, key=lambda x: x[1], reverse=True)

# Prioritize large files for parallel reads
large_files = [f"s3://{bucket}/{key}" for key, size in sorted_files[:10]]
small_files = [f"s3://{bucket}/{key}" for key, size in sorted_files[10:]]

# Read large files with high parallelism
large_df = spark.read.option("maxPartitionBytes", 64 * 1024 * 1024).parquet(*large_files)

# Read small files with default settings
small_df = spark.read.parquet(*small_files)

# Union all
combined_df = large_df.unionByName(small_df, allowMissingColumns=True)
