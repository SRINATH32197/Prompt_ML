PROBLEM STATEMENT : 

Using `mapPartitions` instead of `map` for efficiency.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Using `mapPartitions` instead of `map` for efficiency.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("MapPartitionsEfficiency").getOrCreate()

# Load dataset
rdd = spark.read.parquet("s3://bucket/large_dataset/").rdd

# Use mapPartitions for efficient batch processing
def process_partition(iterator):
    result = []
    for row in iterator:
        transformed = (row['id'], row['value'] * 2)
        result.append(transformed)
    return result

processed_rdd = rdd.mapPartitions(process_partition)

# Convert back to DataFrame
processed_df = processed_rdd.toDF(["id", "value_doubled"])

# Write output
processed_df.write.mode("overwrite").parquet("s3://bucket/processed_output/")
