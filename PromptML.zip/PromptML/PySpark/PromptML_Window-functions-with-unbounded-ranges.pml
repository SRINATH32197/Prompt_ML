PROBLEM STATEMENT : 

Window functions with unbounded ranges on large datasets.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Window functions with unbounded ranges on large datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, col
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("UnboundedWindowFunctions").getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/transactions/")

# Define unbounded window spec
window_spec = Window.partitionBy("customer_id").orderBy("transaction_time") \
                    .rowsBetween(Window.unboundedPreceding, Window.currentRow)

# Apply cumulative sum
df_with_cumsum = df.withColumn("running_total", sum(col("amount")).over(window_spec))

# process df_with_cumsum as needed
