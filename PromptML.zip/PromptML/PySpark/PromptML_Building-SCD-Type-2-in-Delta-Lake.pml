PROBLEM STATEMENT : 

Building SCD Type 2 in Delta Lake.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Building SCD Type 2 in Delta Lake.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit
from delta.tables import DeltaTable

spark = SparkSession.builder \
    .appName("SCDType2DeltaLake") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Load incoming data
incoming_df = spark.read.parquet("s3://bucket/incoming_data/") \
    .withColumn("start_date", current_timestamp()) \
    .withColumn("end_date", lit(None).cast("timestamp")) \
    .withColumn("is_current", lit(True))

# Load existing Delta table
delta_table = DeltaTable.forPath(spark, "s3://bucket/scd2_table/")

# Identify changed records
updates_df = incoming_df.alias("incoming").join(
    delta_table.toDF().alias("existing"),
    "id"
).filter("incoming.hash != existing.hash AND existing.is_current = true") \
 .select("incoming.*")

# Expire old records
delta_table.alias("target").merge(
    updates_df.alias("source"),
    "target.id = source.id AND target.is_current = true"
).whenMatchedUpdate(set={
    "end_date": "current_timestamp()",
    "is_current": "false"
}).execute()

# Insert new records
updates_df.write \
    .format("delta") \
    .mode("append") \
    .save("s3://bucket/scd2_table/")
```