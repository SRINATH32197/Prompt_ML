PROBLEM STATEMENT : 

Avoiding repeated computation with checkpointing.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Avoiding repeated computation with checkpointing.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("AvoidRepeatedComputationWithCheckpointing") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Set checkpoint directory
spark.sparkContext.setCheckpointDir("s3://bucket/checkpoints/")

# Load and transform large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")
transformed_df = df.filter("status = 'active'").groupBy("region").count()

# Persist intermediate result and checkpoint
persisted_df = transformed_df.persist()
checkpointed_df = persisted_df.checkpoint(eager=True)

# Trigger action to materialize checkpoint
checkpointed_df.count()

# Continue downstream processing
final_df = checkpointed_df.filter("count > 100")

# Write output
final_df.write.mode("overwrite").parquet("s3://bucket/final_output/")
