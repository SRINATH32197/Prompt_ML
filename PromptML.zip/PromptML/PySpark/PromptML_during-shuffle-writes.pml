PROBLEM STATEMENT : 

during shuffle writes.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        during shuffle writes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT : 

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("OptimizeShuffleWrites") \
    .config("spark.sql.shuffle.partitions", "200") \
    .config("spark.shuffle.compress", "true") \
    .config("spark.shuffle.spill.compress", "true") \
    .config("spark.shuffle.file.buffer", "64k") \
    .config("spark.reducer.maxSizeInFlight", "48m") \
    .config("spark.shuffle.sort.bypassMergeThreshold", "200") \
    .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
    .getOrCreate()

# Load dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Repartition to control shuffle granularity
df_repartitioned = df.repartition(200, "region")

# Shuffle-heavy aggregation
aggregated_df = df_repartitioned.groupBy("region").agg({"sales": "sum"})

# Write output
aggregated_df.write.mode("overwrite").parquet("s3://bucket/shuffle_optimized_output/")
