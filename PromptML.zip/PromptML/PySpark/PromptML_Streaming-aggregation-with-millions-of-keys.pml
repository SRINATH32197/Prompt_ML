PROBLEM STATEMENT : 

Streaming aggregation with millions of keys.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Streaming aggregation with millions of keys.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder \
    .appName("StreamingAggregationMillionsOfKeys") \
    .config("spark.sql.shuffle.partitions", "1000") \
    .config("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider") \
    .config("spark.sql.streaming.stateStore.rocksdb.enableIncrementalCheckpointing", "true") \
    .config("spark.sql.streaming.stateStore.rocksdb.compactOnBackground", "true") \
    .getOrCreate()

# Read from Kafka
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Aggregation with watermark and millions of keys
aggregated_df = parsed_df \
    .withWatermark("timestamp", "15 minutes") \
    .groupBy(col("key")) \
    .count()

# Write output
aggregated_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/millions_keys_aggregation_output/") \
    .option("checkpointLocation", "s3://bucket/millions_keys_aggregation_checkpoint/") \
    .outputMode("update") \
    .start() \
    .awaitTermination()
