PROBLEM STATEMENT : 

Loading ORC tables with inconsistent schema evolution.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Loading ORC tables with inconsistent schema evolution.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import lit

spark = SparkSession.builder.appName("ORCSchemaEvolution").getOrCreate()

# Read ORC files with schema merging
df = spark.read.option("mergeSchema", "true").orc("s3://bucket/orc_tables/")

# Define expected schema columns
expected_columns = ["id", "name", "timestamp", "status", "source"]

# Add missing columns with default values
for col_name in expected_columns:
    if col_name not in df.columns:
        df = df.withColumn(col_name, lit(None))

# Write back with unified schema
df.write.option("mergeSchema", "true").mode("append").orc("s3://bucket/orc_output/")
