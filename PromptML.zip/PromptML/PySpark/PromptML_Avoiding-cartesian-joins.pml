PROBLEM STATEMENT : 

Avoiding cartesian joins in high -volume datasets.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Avoiding cartesian joins in high -volume datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast

spark = SparkSession.builder.appName("AvoidCartesianJoin").getOrCreate()

# Load datasets
left_df = spark.read.parquet("s3://bucket/left_table/")
right_df = spark.read.parquet("s3://bucket/right_table/")

# Ensure join keys exist and are not null
filtered_left = left_df.filter("join_key IS NOT NULL")
filtered_right = right_df.filter("join_key IS NOT NULL")

# Use broadcast join if right_df is small
joined_df = filtered_left.join(broadcast(filtered_right), "join_key", "inner")

# Validate join key cardinality to avoid cartesian explosion
# Optionally repartition before join if skewed
partitioned_left = filtered_left.repartition("join_key")
partitioned_right = filtered_right.repartition("join_key")

# Perform safe join
safe_join = partitioned_left.join(partitioned_right, "join_key", "inner")
