PROBLEM STATEMENT : 

Avoiding shuffle explosions in groupBy operations.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Avoiding shuffle explosions in groupBy operations.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, rand, concat_ws

spark = SparkSession.builder.appName("AvoidShuffleExplosionGroupBy").getOrCreate()

# Load skewed dataset
df = spark.read.parquet("s3://bucket/skewed_data/")

# Add salt key to reduce shuffle skew
salted_df = df.withColumn("salt", (rand() * 10).cast("int")) \
              .withColumn("group_key_salted", concat_ws("_", col("group_key"), col("salt")))

# Perform groupBy on salted key
aggregated_df = salted_df.groupBy("group_key_salted") \
                         .agg({"metric": "sum"}) \
                         .withColumnRenamed("sum(metric)", "metric_sum")

# Extract original group key
final_df = aggregated_df.withColumn("group_key", col("group_key_salted").substr(1, col("group_key_salted").length() - 2)) \
                        .groupBy("group_key") \
                        .agg({"metric_sum": "sum"}) \
                        .withColumnRenamed("sum(metric_sum)", "total_metric")

# Write output
final_df.write.mode("overwrite").parquet("s3://bucket/grouped_output/")
