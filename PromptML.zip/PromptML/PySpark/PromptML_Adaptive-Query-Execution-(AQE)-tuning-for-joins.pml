PROBLEM STATEMENT : 

Adaptive Query Execution (AQE) tuning for joins. 20 Handling spill -over


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Adaptive Query Execution (AQE) tuning for joins. 20 Handling spill -over
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("AQEJoinSpillHandling") \
    .config("spark.sql.adaptive.enabled", "true") \
    .config("spark.sql.adaptive.join.enabled", "true") \
    .config("spark.sql.adaptive.skewJoin.enabled", "true") \
    .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
    .config("spark.sql.adaptive.localShuffleReader.enabled", "true") \
    .config("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "134217728") \  # 128MB
    .config("spark.sql.autoBroadcastJoinThreshold", "-1") \
    .config("spark.sql.shuffle.partitions", "200") \
    .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
    .config("spark.memory.fraction", "0.6") \
    .config("spark.memory.storageFraction", "0.3") \
    .config("spark.executor.memory", "8g") \
    .config("spark.executor.memoryOverhead", "2g") \
    .getOrCreate()

# Load datasets
left_df = spark.read.parquet("s3://bucket/left_table/")
right_df = spark.read.parquet("s3://bucket/right_table/")

# Join with AQE and spill-over handling
joined_df = left_df.join(right_df, "join_key", "inner")

# Write output
joined_df.write.mode("overwrite").parquet("s3://bucket/aqe_join_output/")
