PROBLEM STATEMENT : 

“as-of” joins for temporal datasets.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        “as-of” joins for temporal datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, row_number
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("AsOfJoinTemporal").getOrCreate()

# Load temporal datasets
events_df = spark.read.parquet("s3://bucket/events/")
reference_df = spark.read.parquet("s3://bucket/reference/")

# Ensure timestamps are properly typed
events_df = events_df.withColumn("event_ts", col("event_ts").cast("timestamp"))
reference_df = reference_df.withColumn("ref_ts", col("ref_ts").cast("timestamp"))

# Perform cross join with filter for as-of condition
joined_df = events_df.alias("e").join(
    reference_df.alias("r"),
    (col("e.key") == col("r.key")) & (col("r.ref_ts") <= col("e.event_ts")),
    "inner"
)

# Use window to select latest reference record per event
window_spec = Window.partitionBy("e.event_id").orderBy(col("r.ref_ts").desc())
asof_df = joined_df.withColumn("row_num", row_number().over(window_spec)) \
                   .filter(col("row_num") == 1) \
                   .drop("row_num")

# Write output
asof_df.write.mode("overwrite").parquet("s3://bucket/asof_join_output/")

