PROBLEM STATEMENT : 

Streaming ingestion from Kafka with schema changes.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Streaming ingestion from Kafka with schema changes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, DoubleType

spark = SparkSession.builder.appName("KafkaStreamingSchemaEvolution").getOrCreate()

# Define evolving schema (latest version)
schema_v2 = StructType() \
    .add("event_type", StringType()) \
    .add("user_id", StringType()) \
    .add("duration", DoubleType()) \
    .add("metadata", StructType()
         .add("ip", StringType())
         .add("device", StringType()))

# Read from Kafka
raw_stream = spark.readStream.format("kafka") \
    .option("kafka.bootstrap.servers", "broker:9092") \
    .option("subscribe", "events_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Extract value and parse JSON with latest schema
parsed_stream = raw_stream.selectExpr("CAST(value AS STRING) as json_str") \
    .withColumn("json_data", from_json(col("json_str"), schema_v2))

# Flatten fields with null-safe access
flattened_stream = parsed_stream.select(
    col("json_data.event_type"),
    col("json_data.user_id"),
    col("json_data.duration"),
    col("json_data.metadata.ip"),
    col("json_data.metadata.device")
)

# Write to sink with checkpointing
flattened_stream.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/stream_output/") \
    .option("checkpointLocation", "s3://bucket/checkpoints/kafka_stream/") \
    .outputMode("append") \
    .start()
