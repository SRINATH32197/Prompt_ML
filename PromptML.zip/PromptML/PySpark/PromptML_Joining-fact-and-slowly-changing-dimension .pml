PROBLEM STATEMENT : 

Joining fact and slowly changing dimension (SCD Type 2).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Joining fact and slowly changing dimension (SCD Type 2).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import TimestampType

spark = SparkSession.builder.appName("JoinFactWithSCD2").getOrCreate()

# Load fact and dimension tables
fact_df = spark.read.parquet("s3://bucket/fact_table/")
dim_df = spark.read.parquet("s3://bucket/scd2_dimension/")

# Ensure timestamp columns are properly typed
fact_df = fact_df.withColumn("event_ts", col("event_ts").cast(TimestampType()))
dim_df = dim_df.withColumn("effective_from", col("effective_from").cast(TimestampType())) \
               .withColumn("effective_to", col("effective_to").cast(TimestampType()))

# Join fact with SCD Type 2 dimension
joined_df = fact_df.join(
    dim_df,
    (fact_df["dim_key"] == dim_df["dim_key"]) &
    (fact_df["event_ts"] >= dim_df["effective_from"]) &
    (fact_df["event_ts"] < dim_df["effective_to"]),
    "left"
)

# process joined_df as needed
