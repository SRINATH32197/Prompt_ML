PROBLEM STATEMENT : 

Managing checkpoint corruption in streaming.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Managing checkpoint corruption in streaming.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import shutil
import os

spark = SparkSession.builder \
    .appName("CheckpointCorruptionRecovery") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Define checkpoint and output paths
checkpoint_path = "s3://bucket/stream_checkpoint/"
output_path = "s3://bucket/stream_output/"

# Optional: clean corrupted checkpoint manually (use with caution)
def clean_corrupted_checkpoint(path):
    if path.startswith("s3://"):
        # Use AWS SDK or CLI externally to clean S3 checkpoint
        pass
    else:
        if os.path.exists(path):
            shutil.rmtree(path)

# Uncomment to clean local corrupted checkpoint
# clean_corrupted_checkpoint("/mnt/checkpoint_dir")

# Read streaming source
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Write stream with fresh checkpoint if corruption detected
parsed_df.writeStream \
    .format("parquet") \
    .option("path", output_path) \
    .option("checkpointLocation", checkpoint_path) \
    .outputMode("append") \
    .start() \
    .awaitTermination()
