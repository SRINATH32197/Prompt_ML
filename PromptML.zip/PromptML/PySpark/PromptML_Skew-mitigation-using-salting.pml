PROBLEM STATEMENT : 

Skew mitigation using salting.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Skew mitigation using salting.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................

COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import rand, col

spark = SparkSession.builder.appName("SkewMitigationUsingSalting").getOrCreate()

# Load skewed large dataset and small dimension dataset
large_df = spark.read.parquet("s3://bucket/large_table/")
small_df = spark.read.parquet("s3://bucket/small_table/")

# Add salt key to large dataset
salted_large = large_df.withColumn("salt", (rand() * 10).cast("int"))

# Duplicate small dataset for each salt value
salted_small = small_df.crossJoin(spark.range(0, 10).toDF("salt"))

# Join on salted keys
joined_df = salted_large.join(
    salted_small,
    (salted_large["join_key"] == salted_small["join_key"]) &
    (salted_large["salt"] == salted_small["salt"]),
    "inner"
)

# Write output
joined_df.write.mode("overwrite").parquet("s3://bucket/skew_mitigated_output/")
