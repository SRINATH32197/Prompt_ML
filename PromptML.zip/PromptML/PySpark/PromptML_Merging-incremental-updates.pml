PROBLEM STATEMENT : 

Merging incremental updates with CDC logic.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Merging incremental updates with CDC logic.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, row_number
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("CDCMergeIncremental").getOrCreate()

# Load base and incremental datasets
base_df = spark.read.parquet("s3://bucket/base_table/")
incremental_df = spark.read.parquet("s3://bucket/incremental_updates/")

# Combine and deduplicate using CDC logic
combined_df = base_df.unionByName(incremental_df)

# Apply window to get latest record per key
window_spec = Window.partitionBy("primary_key").orderBy(col("update_ts").desc())
latest_df = combined_df.withColumn("row_num", row_number().over(window_spec)) \
                       .filter(col("row_num") == 1) \
                       .drop("row_num")

# Write merged output
latest_df.write.mode("overwrite").parquet("s3://bucket/merged_table/")
