PROBLEM STATEMENT : 

Implementing multi -level aggregations (rollup/cube).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Implementing multi -level aggregations (rollup/cube).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import sum

spark = SparkSession.builder.appName("MultiLevelAggregation").getOrCreate()

# Load data
df = spark.read.parquet("s3://bucket/sales_data/")

# Rollup aggregation
rollup_df = df.rollup("region", "product") \
              .agg(sum("revenue").alias("total_revenue")) \
              .orderBy("region", "product")

# Cube aggregation
cube_df = df.cube("region", "product") \
            .agg(sum("revenue").alias("total_revenue")) \
            .orderBy("region", "product")
