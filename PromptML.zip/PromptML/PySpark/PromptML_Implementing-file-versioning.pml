PROBLEM STATEMENT : 

Implementing file versioning in data lake ingestion.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Implementing file versioning in data lake ingestion.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit
import boto3

spark = SparkSession.builder.appName("FileVersioningIngestion").getOrCreate()

# S3 config
bucket = "bucket"
prefix = "data/incoming/"
versioned_path = "s3://bucket/data/versioned/"
s3 = boto3.client("s3")

# List incoming files
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
incoming_files = [obj["Key"] for obj in response.get("Contents", [])
                  if obj["Key"].endswith(".parquet") and not obj["Key"].split("/")[-1].startswith(("_", "."))]

# Load and tag version
for key in incoming_files:
    version = current_timestamp().cast("string")
    path = f"s3://{bucket}/{key}"
    df = spark.read.parquet(path).withColumn("version", lit(version))
    
    # Write to versioned location
    df.write.mode("append").parquet(versioned_path)
