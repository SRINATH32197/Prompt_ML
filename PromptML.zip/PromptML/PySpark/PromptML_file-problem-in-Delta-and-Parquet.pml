PROBLEM STATEMENT : 

Optimizing small file problem in Delta/Parquet.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Optimizing small file problem in Delta/Parquet.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("OptimizeSmallFiles") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Load fragmented Delta/Parquet table
df = spark.read.format("delta").load("s3://bucket/delta_table/")

# Coalesce to reduce file count before write
optimized_df = df.coalesce(50)

# Overwrite with optimized layout
optimized_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("dataChange", "false") \
    .save("s3://bucket/delta_table_optimized/")

# Optional: Compact existing Delta table using OPTIMIZE if using Databricks
# spark.sql("OPTIMIZE delta.`s3://bucket/delta_table/`")
