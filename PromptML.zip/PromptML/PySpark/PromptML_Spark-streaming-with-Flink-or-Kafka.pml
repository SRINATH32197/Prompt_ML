PROBLEM STATEMENT : 

Integrating Spark streaming with Flink or Kafka Streams.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Integrating Spark streaming with Flink or Kafka Streams.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

spark = SparkSession.builder \
    .appName("SparkFlinkKafkaIntegration") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Read from Kafka (produced by Flink or Kafka Streams)
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "flink_kafka_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Apply transformation
transformed_df = parsed_df.withWatermark("timestamp", "10 minutes") \
    .groupBy(expr("key"), expr("window(timestamp, '5 minutes')")) \
    .count()

# Write to Kafka (consumable by Flink or Kafka Streams)
transformed_df.selectExpr("CAST(key AS STRING) AS key", "CAST(count AS STRING) AS value") \
    .writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("topic", "spark_output_topic") \
    .option("checkpointLocation", "s3://bucket/spark_flink_kafka_checkpoint/") \
    .outputMode("update") \
    .start() \
    .awaitTermination()
