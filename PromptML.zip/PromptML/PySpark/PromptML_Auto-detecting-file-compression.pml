PROBLEM STATEMENT : 

Auto-detecting file compression (gzip, snappy, bzip2).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Auto-detecting file compression (gzip, snappy, bzip2).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import boto3

spark = SparkSession.builder.appName("AutoDetectCompression").getOrCreate()

# List files from S3
s3 = boto3.client("s3")
bucket = "bucket"
prefix = "path/"
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

# Detect compression from file extension
compression_map = {
    ".gz": "gzip",
    ".snappy": "snappy",
    ".bz2": "bzip2"
}

def detect_compression(key):
    for ext, codec in compression_map.items():
        if key.endswith(ext):
            return codec
    return None

valid_files = [(key, detect_compression(key)) for key in 
               [obj["Key"] for obj in response.get("Contents", [])]
               if not key.split("/")[-1].startswith(("_", "."))]

# Read files with detected compression
for key, codec in valid_files:
    path = f"s3://{bucket}/{key}"
    df = spark.read.option("compression", codec).csv(path)
    # process df as needed
