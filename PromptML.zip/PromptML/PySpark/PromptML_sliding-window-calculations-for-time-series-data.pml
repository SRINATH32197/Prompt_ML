PROBLEM STATEMENT : 

Performing sliding window calculations for time -series data. 19 Handling


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Performing sliding window calculations for time -series data. 19 Handling
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("SlidingWindowTimeSeries").getOrCreate()

# Load time-series data
df = spark.read.parquet("s3://bucket/time_series_data/")

# Define sliding window spec (e.g., last 5 rows including current)
window_spec = Window.partitionBy("entity_id").orderBy("event_ts") \
                    .rowsBetween(-4, 0)

# Apply sliding window aggregation
sliding_avg_df = df.withColumn("sliding_avg", avg(col("metric")).over(window_spec))

# Write output
sliding_avg_df.write.mode("overwrite").parquet("s3://bucket/sliding_window_output/")
