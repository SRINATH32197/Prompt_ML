PROBLEM STATEMENT : 

Multi -cluster reads/writes to Delta Lake.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Multi -cluster reads/writes to Delta Lake.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT : 

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaMultiClusterAccess") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.databricks.delta.crossCluster.read.enabled", "true") \
    .config("spark.databricks.delta.crossCluster.write.enabled", "true") \
    .getOrCreate()

# Read from shared Delta table
df = spark.read.format("delta").load("s3://shared-bucket/delta_table/")

# Transform data
transformed_df = df.filter("status = 'active'")

# Write back to shared Delta table
transformed_df.write \
    .format("delta") \
    .mode("append") \
    .save("s3://shared-bucket/delta_table/")
```