PROBLEM STATEMENT : 

Detecting and ignoring hidden/system files (`_SUCCESS`, `.crc`).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Detecting and ignoring hidden/system files (`_SUCCESS`, `.crc`).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import boto3

spark = SparkSession.builder.appName("IgnoreSystemFiles").getOrCreate()

# List non-hidden files from S3
s3 = boto3.client("s3")
bucket = "bucket"
prefix = "path/"
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

valid_keys = [obj["Key"] for obj in response.get("Contents", [])
              if not obj["Key"].split("/")[-1].startswith(("_", "."))]

# Construct full S3 paths
valid_paths = [f"s3://{bucket}/{key}" for key in valid_keys]

# Read only valid files
df = spark.read.parquet(*valid_paths)

