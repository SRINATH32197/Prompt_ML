PROBLEM STATEMENT : 

Joining batch data with streaming data.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Joining batch data with streaming data.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr, col
from pyspark.sql.types import StringType

spark = SparkSession.builder.appName("JoinBatchWithStreaming").getOrCreate()

# Load batch data
batch_df = spark.read.parquet("s3://bucket/batch_reference_data/")

# Read streaming data
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse Kafka payload
parsed_stream_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Join streaming with batch (broadcast batch for efficiency)
joined_df = parsed_stream_df.join(batch_df.hint("broadcast"), parsed_stream_df["key"] == batch_df["lookup_key"], "inner")

# Write output
joined_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/joined_stream_batch_output/") \
    .option("checkpointLocation", "s3://bucket/joined_stream_batch_checkpoint/") \
    .outputMode("append") \
    .start() \
    .awaitTermination()
