PROBLEM STATEMENT : 

Handling ACID transactions in Delta Lake.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling ACID transactions in Delta Lake.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from pyspark.sql.functions import expr

spark = SparkSession.builder \
    .appName("DeltaLakeACIDTransactions") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Load source data
source_df = spark.read.parquet("s3://bucket/source_data/")

# Define Delta table path
delta_path = "s3://bucket/delta_table/"

# Create Delta table if not exists
source_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save(delta_path)

# Load Delta table
delta_table = DeltaTable.forPath(spark, delta_path)

# Perform ACID-compliant upsert
updates_df = spark.read.parquet("s3://bucket/update_data/")

delta_table.alias("target").merge(
    updates_df.alias("source"),
    "target.id = source.id"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
```