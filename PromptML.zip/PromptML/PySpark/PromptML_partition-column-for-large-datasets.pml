PROBLEM STATEMENT : 

Choosing the right partition column for large datasets.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Choosing the right partition column for large datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count

spark = SparkSession.builder.appName("PartitionColumnSelection").getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Analyze cardinality and distribution of candidate columns
candidate_columns = ["region", "country", "date", "user_id"]

for col_name in candidate_columns:
    df.groupBy(col_name).agg(count("*").alias("cnt")) \
      .orderBy("cnt", ascending=False) \
      .show(5)

# Choose column with high cardinality and even distribution (e.g., 'date')
partitioned_df = df.repartition("date")

# Write partitioned output
partitioned_df.write.partitionBy("date").mode("overwrite").parquet("s3://bucket/partitioned_output/")
