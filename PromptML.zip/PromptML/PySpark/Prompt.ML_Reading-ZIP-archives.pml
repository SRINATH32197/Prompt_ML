PROBLEM STATEMENT : 

Reading ZIP archives without fully ex tracting them.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Reading ZIP archives without fully ex tracting them.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :


from pyspark.sql import SparkSession
import zipfile
import io
import boto3

spark = SparkSession.builder.appName("ReadZipInMemory").getOrCreate()
sc = spark.sparkContext

def read_zip_from_s3(bucket, key):
    s3 = boto3.client('s3')
    zip_obj = s3.get_object(Bucket=bucket, Key=key)['Body'].read()
    with zipfile.ZipFile(io.BytesIO(zip_obj)) as z:
        for filename in z.namelist():
            with z.open(filename) as f:
                yield f.read().decode('utf-8')

bucket = "your-bucket-name"
key = "path/to/your.zip"

rdd = sc.parallelize(read_zip_from_s3(bucket, key))
df = spark.read.csv(rdd)
df.show()
