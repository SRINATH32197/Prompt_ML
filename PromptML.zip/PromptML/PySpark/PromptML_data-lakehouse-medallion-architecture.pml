PROBLEM STATEMENT : 

Building data lakehouse medallion architecture.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Building data lakehouse medallion architecture.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small 
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr

spark = SparkSession.builder \
    .appName("LakehouseMedallionArchitecture") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Bronze: Raw ingestion
bronze_df = spark.readStream \
    .format("json") \
    .option("path", "s3://lakehouse/bronze/raw_events/") \
    .option("maxFilesPerTrigger", 10) \
    .load()

bronze_df.writeStream \
    .format("delta") \
    .option("checkpointLocation", "s3://lakehouse/bronze/checkpoints/") \
    .outputMode("append") \
    .start("s3://lakehouse/bronze/table/")

# Silver: Cleaned and enriched
silver_df = bronze_df \
    .filter(col("event_type").isNotNull()) \
    .withColumn("event_date", expr("to_date(event_ts)"))

silver_df.writeStream \
    .format("delta") \
    .option("checkpointLocation", "s3://lakehouse/silver/checkpoints/") \
    .outputMode("append") \
    .start("s3://lakehouse/silver/table/")

# Gold: Aggregated analytics
gold_df = silver_df \
    .groupBy("event_type", "event_date") \
    .count()

gold_df.writeStream \
    .format("delta") \
    .option("checkpointLocation", "s3://lakehouse/gold/checkpoints/") \
    .outputMode("complete") \
    .start("s3://lakehouse/gold/table/")
```