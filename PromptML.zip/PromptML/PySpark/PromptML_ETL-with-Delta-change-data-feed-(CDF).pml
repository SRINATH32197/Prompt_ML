PROBLEM STATEMENT : 

Incremental ETL with Delta change data feed (CDF).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Incremental ETL with Delta change data feed (CDF).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaCDFIncrementalETL") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Define source Delta table with CDF enabled
source_path = "s3://bucket/source_table/"
start_version = 100

# Read changes from Delta using CDF
cdf_df = spark.read.format("delta") \
    .option("readChangeData", "true") \
    .option("startingVersion", start_version) \
    .table("delta.`{}`".format(source_path))

# Filter only inserts and updates
filtered_df = cdf_df.filter("change_type IN ('insert', 'update_postimage')")

# Write to target Delta table
filtered_df.write \
    .format("delta") \
    .mode("append") \
    .save("s3://bucket/target_table/")
```