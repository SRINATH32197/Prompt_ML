PROBLEM STATEMENT : 

Balancing memory vs. disk in Spark configurations.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Balancing memory vs. disk in Spark configurations.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark import StorageLevel

spark = SparkSession.builder \
    .appName("BalanceMemoryDisk") \
    .config("spark.executor.memory", "8g") \
    .config("spark.executor.memoryOverhead", "2g") \
    .config("spark.memory.fraction", "0.6") \
    .config("spark.memory.storageFraction", "0.3") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Persist with MEMORY_AND_DISK to balance memory and spill to disk
balanced_df = df.persist(StorageLevel.MEMORY_AND_DISK)

# Trigger action to materialize
balanced_df.count()

# Downstream transformation
aggregated_df = balanced_df.groupBy("region").agg({"sales": "sum"})

# Write output
aggregated_df.write.mode("overwrite").parquet("s3://bucket/memory_disk_balanced_output/")

