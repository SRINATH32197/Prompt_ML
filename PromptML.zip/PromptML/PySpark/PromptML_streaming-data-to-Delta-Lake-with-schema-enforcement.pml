PROBLEM STATEMENT : 

Writing streaming data to Delta Lake with schema enforcement.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Writing streaming data to Delta Lake with schema enforcement.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StringType, TimestampType

spark = SparkSession.builder \
    .appName("StreamingToDeltaWithSchemaEnforcement") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Define schema explicitly
schema = StructType() \
    .add("event_id", StringType()) \
    .add("event_type", StringType()) \
    .add("event_ts", TimestampType())

# Read streaming data
stream_df = spark.readStream \
    .format("json") \
    .schema(schema) \
    .option("path", "s3://bucket/stream_input/") \
    .option("maxFilesPerTrigger", 10) \
    .load()

# Write to Delta Lake with schema enforcement
stream_df.writeStream \
    .format("delta") \
    .option("checkpointLocation", "s3://bucket/delta_checkpoint/") \
    .outputMode("append") \
    .start("s3://bucket/delta_output/") \
    .awaitTermination()
```