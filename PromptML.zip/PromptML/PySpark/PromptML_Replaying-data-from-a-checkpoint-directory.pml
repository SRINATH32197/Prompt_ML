PROBLEM STATEMENT : 

Replaying data from a checkpoint directory.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Replaying data from a checkpoint directory.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("ReplayFromCheckpoint") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Replay streaming job from checkpoint
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "earliest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Write output using existing checkpoint to resume
parsed_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/replayed_output/") \
    .option("checkpointLocation", "s3://bucket/existing_checkpoint_dir/") \
    .outputMode("append") \
    .start() \
    .awaitTermination()
