PROBLEM STATEMENT : 

Performing complex joins on nested JSON arrays.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Performing complex joins on nested JSON arrays.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, col

spark = SparkSession.builder.appName("NestedJSONJoin").getOrCreate()

# Load JSON datasets
orders_df = spark.read.option("multiLine", "true").json("s3://bucket/orders.json")
products_df = spark.read.json("s3://bucket/products.json")

# Explode nested array in orders
exploded_orders = orders_df.withColumn("item", explode(col("order_items"))) \
    .select(
        col("order_id"),
        col("customer_id"),
        col("item.product_id").alias("product_id"),
        col("item.quantity").alias("quantity")
    )

# Join with product details
joined_df = exploded_orders.join(products_df, "product_id", "left")

# process joined_df as needed
