PROBLEM STATEMENT : 

Optimizing broadcast joins with large broadcast data.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Optimizing broadcast joins with large broadcast data.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast

spark = SparkSession.builder \
    .appName("OptimizedBroadcastJoin") \
    .config("spark.sql.autoBroadcastJoinThreshold", 104857600) \  # 100MB
    .config("spark.sql.broadcastTimeout", "600") \
    .getOrCreate()

# Load datasets
large_df = spark.read.parquet("s3://bucket/large_table/")
broadcast_df = spark.read.parquet("s3://bucket/broadcast_table/")

# Repartition broadcast_df to reduce shuffle during broadcast
optimized_broadcast_df = broadcast_df.repartition(50)

# Persist broadcast_df to avoid recomputation
optimized_broadcast_df.cache()
optimized_broadcast_df.count()

# Perform broadcast join
joined_df = large_df.join(broadcast(optimized_broadcast_df), "join_key", "inner")

# Write output
joined_df.write.mode("overwrite").parquet("s3://bucket/broadcast_join_output/")
