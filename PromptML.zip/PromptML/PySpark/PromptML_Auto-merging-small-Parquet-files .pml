PROBLEM STATEMENT : 

Auto-merging small Parquet files into larger ones.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Auto-merging small Parquet files into larger ones.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("MergeSmallParquetFiles").getOrCreate()

# Read small Parquet files
df = spark.read.parquet("s3://bucket/small_files/")

# Repartition to reduce number of output files
coalesced_df = df.coalesce(10)

# Write out compacted Parquet files
coalesced_df.write.mode("overwrite").parquet("s3://bucket/merged_output/")
