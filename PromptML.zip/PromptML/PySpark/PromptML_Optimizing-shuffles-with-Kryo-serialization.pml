PROBLEM STATEMENT : 

Optimizing shuffles with Kryo serialization.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Optimizing shuffles with Kryo serialization.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("OptimizeShufflesWithKryo") \
    .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
    .config("spark.kryo.registrationRequired", "false") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Repartition to control shuffle parallelism
df_repartitioned = df.repartition(200, "region")

# Perform shuffle-heavy aggregation
aggregated_df = df_repartitioned.groupBy("region").agg({"sales": "sum"})

# Write output
aggregated_df.write.mode("overwrite").parquet("s3://bucket/kryo_optimized_output/")
