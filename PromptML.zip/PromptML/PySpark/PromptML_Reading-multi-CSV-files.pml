PROBLEM STATEMENT : 

Reading multi -gigabyte CSV files with inconsistent delimiters.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Reading multi -gigabyte CSV files with inconsistent delimiters.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name, lit
import re

spark = SparkSession.builder.appName("InconsistentDelimiterCSVReader").getOrCreate()

# Define possible delimiters
delimiters = [",", ";", "\t", "|"]

# Sample function to infer delimiter from a line
def infer_delimiter(line):
    counts = {d: line.count(d) for d in delimiters}
    return max(counts, key=counts.get)

# Read raw lines and infer delimiter per file
raw_rdd = spark.sparkContext.textFile("s3://bucket/path/*.csv")

# Extract delimiter from first non-empty line
sample_line = raw_rdd.filter(lambda x: x.strip() != "").take(1)[0]
detected_delim = infer_delimiter(sample_line)

# Read using inferred delimiter
df = spark.read.option("header", "true").option("delimiter", detected_delim).csv("s3://bucket/path/*.csv")

# Optional: tag source file
df = df.withColumn("source_file", input_file_name())
