PROBLEM STATEMENT : 

Enabling row -level security in Delta Lake.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Enabling row -level security in Delta Lake.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaRowLevelSecurity") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Create Delta table with row-level access column
spark.sql("""
    CREATE TABLE delta.`s3://bucket/secure_table/` (
        id STRING,
        name STRING,
        department STRING,
        access_group STRING
    ) USING DELTA
""")

# Simulate user context
user_group = "finance"

# Apply row-level filter based on access group
secure_df = spark.read.format("delta").load("s3://bucket/secure_table/") \
    .filter(f"access_group = '{user_group}'")

secure_df.show()
```