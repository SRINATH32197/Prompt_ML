PROBLEM STATEMENT : 

Handling many -to-many relationships in joins.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling many -to-many relationships in joins.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, col

spark = SparkSession.builder.appName("ManyToManyJoin").getOrCreate()

# Load datasets
products_df = spark.read.parquet("s3://bucket/products/")
categories_df = spark.read.parquet("s3://bucket/categories/")

# Assume products_df has a column 'category_ids' as array of category keys
# Explode to normalize many-to-many relationship
exploded_products = products_df.withColumn("category_id", explode(col("category_ids")))

# Join with category details
joined_df = exploded_products.join(categories_df, "category_id", "inner")

# process joined_df as needed
