PROBLEM STATEMENT : 

Handling schema drift in s treaming JSON payloads.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling schema drift in s treaming JSON payloads.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, TimestampType

spark = SparkSession.builder \
    .appName("HandleSchemaDriftStreamingJSON") \
    .config("spark.sql.streaming.schemaInference", "true") \
    .getOrCreate()

# Define base schema with optional fields
base_schema = StructType() \
    .add("event_id", StringType(), True) \
    .add("event_type", StringType(), True) \
    .add("event_ts", TimestampType(), True)

# Read streaming JSON payloads
stream_df = spark.readStream \
    .format("json") \
    .schema(base_schema) \
    .option("path", "s3://bucket/json_stream_input/") \
    .option("maxFilesPerTrigger", 10) \
    .load()

# Parse and normalize schema drift
normalized_df = stream_df.select(
    col("event_id"),
    col("event_type"),
    col("event_ts")
)

# Write output
normalized_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/schema_drift_output/") \
    .option("checkpointLocation", "s3://bucket/schema_drift_checkpoint/") \
    .outputMode("append") \
    .start() \
    .awaitTermination()
