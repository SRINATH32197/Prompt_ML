PROBLEM STATEMENT : 

Reducing GC overhead for large RDD/DataFrame operations.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Reducing GC overhead for large RDD/DataFrame operations.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark import StorageLevel

spark = SparkSession.builder \
    .appName("ReduceGCOverhead") \
    .config("spark.sql.shuffle.partitions", "200") \
    .config("spark.executor.memory", "8g") \
    .config("spark.executor.memoryOverhead", "2g") \
    .config("spark.memory.fraction", "0.6") \
    .config("spark.memory.storageFraction", "0.3") \
    .getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Persist with disk-only to reduce memory pressure
df_persisted = df.persist(StorageLevel.DISK_ONLY)

# Avoid wide transformations and cache intermediate results
filtered_df = df_persisted.filter("status = 'active'").cache()

# Trigger action to materialize cache
filtered_df.count()

# Downstream aggregation
aggregated_df = filtered_df.groupBy("region").agg({"sales": "sum"})

# Write output
aggregated_df.write.mode("overwrite").parquet("s3://bucket/gc_optimized_output/")
