PROBLEM STATEMENT : 

Skipping duplicate files in incremental data loads.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Skipping duplicate files in incremental data loads.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import boto3
import json

spark = SparkSession.builder.appName("SkipDuplicateFiles").getOrCreate()

# S3 config
bucket = "bucket"
prefix = "data/incremental/"
manifest_path = "s3://bucket/processed_manifest.json"

# Load manifest of already processed files
try:
    manifest_df = spark.read.text(manifest_path)
    processed_files = set(json.loads(manifest_df.collect()[0][0]))
except:
    processed_files = set()

# List current files in S3
s3 = boto3.client("s3")
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
all_files = [obj["Key"] for obj in response.get("Contents", [])
             if not obj["Key"].split("/")[-1].startswith(("_", "."))]

# Filter new files
new_files = [f for f in all_files if f not in processed_files]
new_paths = [f"s3://{bucket}/{key}" for key in new_files]

# Load and process new files
if new_paths:
    df = spark.read.parquet(*new_paths)
    # process df as needed

    # Update manifest
    updated_manifest = json.dumps(list(processed_files.union(new_files)))
    spark.createDataFrame([updated_manifest], "string").write.mode("overwrite").text(manifest_path)
