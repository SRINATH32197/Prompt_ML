PROBLEM STATEMENT : 

Managing concurrent writers in Delta Lake.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Managing concurrent writers in Delta Lake.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from delta.tables import DeltaTable

spark = SparkSession.builder \
    .appName("DeltaConcurrentWriters") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.databricks.delta.concurrentWrites.enabled", "true") \
    .config("spark.databricks.delta.commitInfo.enabled", "true") \
    .getOrCreate()

# Load incoming batch
incoming_df = spark.read.parquet("s3://bucket/incoming_batch/")

# Write with optimistic concurrency control
incoming_df.write \
    .format("delta") \
    .mode("append") \
    .option("mergeSchema", "true") \
    .save("s3://bucket/delta_table/")

# Optional: enforce serializable isolation for critical operations
delta_table = DeltaTable.forPath(spark, "s3://bucket/delta_table/")
spark.sql("SET spark.databricks.delta.isolation.level = Serializable")
```