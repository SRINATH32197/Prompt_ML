PROBLEM STATEMENT : 

Building end -to-end data pipelines with batch + streaming on Delta.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Building end -to-end data pipelines with batch + streaming on Delta.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr

spark = SparkSession.builder \
    .appName("DeltaBatchStreamingPipeline") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Streaming ingestion to Bronze
bronze_stream = spark.readStream \
    .format("json") \
    .option("path", "s3://lakehouse/bronze/raw_events/") \
    .option("maxFilesPerTrigger", 10) \
    .load()

bronze_stream.writeStream \
    .format("delta") \
    .option("checkpointLocation", "s3://lakehouse/bronze/checkpoints/") \
    .outputMode("append") \
    .start("s3://lakehouse/bronze/table/")

# Batch enrichment to Silver
bronze_batch = spark.read.format("delta").load("s3://lakehouse/bronze/table/")
silver_batch = bronze_batch \
    .filter(col("event_type").isNotNull()) \
    .withColumn("event_date", expr("to_date(event_ts)"))

silver_batch.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://lakehouse/silver/table/")

# Streaming aggregation to Gold
silver_stream = spark.readStream.format("delta").load("s3://lakehouse/silver/table/")
gold_stream = silver_stream \
    .groupBy("event_type", "event_date") \
    .count()

gold_stream.writeStream \
    .format("delta") \
    .option("checkpointLocation", "s3://lakehouse/gold/checkpoints/") \
    .outputMode("complete") \
    .start("s3://lakehouse/gold/table/")
```