PROBLEM STATEMENT : 

Handling Kafka offset management manually.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling Kafka offset management manually.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.streaming import StreamingQueryListener

spark = SparkSession.builder \
    .appName("KafkaManualOffsetManagement") \
    .config("spark.sql.streaming.forceDeleteTempCheckpointLocation", "true") \
    .getOrCreate()

# Define Kafka source with manual starting offsets
kafka_df = spark.read \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092,broker2:9092") \
    .option("subscribe", "topic_name") \
    .option("startingOffsets", """{"topic_name":{"0":12345,"1":67890}}""") \
    .load()

# Transform Kafka value
parsed_df = kafka_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "offset", "partition")

# Process and write output
query = parsed_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/kafka_output/") \
    .option("checkpointLocation", "s3://bucket/kafka_checkpoint/") \
    .outputMode("append") \
    .start()

# Listener to track offsets
class OffsetListener(StreamingQueryListener):
    def onQueryProgress(self, event):
        for source in event.progress["sources"]:
            print(f"Offsets: {source['endOffset']}")

spark.streams.addListener(OffsetListener())

query.awaitTermination()
