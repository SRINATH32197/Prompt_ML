PROBLEM STATEMENT : 

Pipelining transformations to reduce job stages.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Pipelining transformations to reduce job stages.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum, when

spark = SparkSession.builder.appName("PipelineTransformations").getOrCreate()

# Load dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Pipeline transformations to minimize stages
result_df = df.filter(col("status") == "active") \
              .withColumn("adjusted_sales", when(col("region") == "APAC", col("sales") * 1.1).otherwise(col("sales"))) \
              .groupBy("region") \
              .agg(sum("adjusted_sales").alias("total_sales")) \
              .filter(col("total_sales") > 100000)

# Write output
result_df.write.mode("overwrite").parquet("s3://bucket/pipelined_output/")
