PROBLEM STATEMENT : 

Handling late -arriving data in event streams.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling late -arriving data in event streams.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, window
from pyspark.sql.types import StructType, StringType, TimestampType

spark = SparkSession.builder.appName("LateArrivingEventStream").getOrCreate()

# Define schema with event timestamp
schema = StructType() \
    .add("event_id", StringType()) \
    .add("event_type", StringType()) \
    .add("event_time", TimestampType())

# Read streaming data from Kafka
stream_df = spark.readStream.format("kafka") \
    .option("kafka.bootstrap.servers", "broker:9092") \
    .option("subscribe", "events_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse JSON payload
parsed_df = stream_df.selectExpr("CAST(value AS STRING) as json_str") \
    .withColumn("data", from_json(col("json_str"), schema)) \
    .select("data.*")

# Apply watermark to handle late data
watermarked_df = parsed_df.withWatermark("event_time", "15 minutes")

# Aggregate over time windows
aggregated_df = watermarked_df.groupBy(
    window(col("event_time"), "10 minutes")
).count()

# Write output with checkpointing
aggregated_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/stream_output/") \
    .option("checkpointLocation", "s3://bucket/checkpoints/late_data/") \
    .outputMode("append") \
    .start()
