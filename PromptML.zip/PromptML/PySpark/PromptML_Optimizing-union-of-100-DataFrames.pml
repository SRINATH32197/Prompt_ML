PROBLEM STATEMENT : 

Optimizing union of 100+ DataFrames without OOM errors.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Optimizing union of 100+ DataFrames without OOM errors.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql import DataFrame
import os

spark = SparkSession.builder.appName("OptimizedUnion").getOrCreate()

# Directory containing 100+ DataFrames as Parquet files
input_dir = "s3://bucket/multiple_sources/"
output_path = "s3://bucket/union_output/"

# List all input files
file_list = [f"s3://bucket/multiple_sources/{f}" for f in os.listdir("/mnt/multiple_sources") if f.endswith(".parquet")]

# Function to load and union in batches
def union_in_batches(paths, batch_size=10):
    unioned = None
    for i in range(0, len(paths), batch_size):
        batch_paths = paths[i:i+batch_size]
        batch_df = spark.read.parquet(*batch_paths)
        unioned = batch_df if unioned is None else unioned.unionByName(batch_df)
        unioned = unioned.persist()
    return unioned

# Execute union
final_df = union_in_batches(file_list, batch_size=10)

# Write output
final_df.write.mode("overwrite").parquet(output_path)
