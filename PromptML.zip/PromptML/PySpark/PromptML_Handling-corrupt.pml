PROBLEM STATEMENT : 

Handling corrupt or malformed JSON records during ingestion.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling corrupt or malformed JSON records during ingestion.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, input_file_name

spark = SparkSession.builder.appName("HandleCorruptJSON").getOrCreate()

# Read JSON with permissive mode to capture corrupt records
df = spark.read.option("mode", "PERMISSIVE") \
               .option("columnNameOfCorruptRecord", "_corrupt_record") \
               .json("s3://bucket/path/*.json")

# Separate valid and corrupt records
valid_df = df.filter(col("_corrupt_record").isNull())
corrupt_df = df.filter(col("_corrupt_record").isNotNull()) \
               .select("_corrupt_record") \
               .withColumn("source_file", input_file_name())

# Optional: write corrupt records for audit/debug
corrupt_df.write.mode("append").parquet("s3://bucket/debug/corrupt_json_records")
