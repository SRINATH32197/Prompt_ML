PROBLEM STATEMENT : 

Estimating optimal partition size in bytes.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Estimating optimal partition size in bytes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import math

spark = SparkSession.builder.appName("EstimateOptimalPartitionSize").getOrCreate()

# Load dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Estimate total size in bytes
total_size_bytes = df.rdd.map(lambda row: len(str(row))).sum()

# Define target partition size (e.g., 128MB)
target_partition_size = 128 * 1024 * 1024  # 128MB in bytes

# Compute optimal number of partitions
optimal_partitions = max(1, math.ceil(total_size_bytes / target_partition_size))

# Repartition accordingly
df_repartitioned = df.repartition(optimal_partitions)

# Write output
df_repartitioned.write.mode("overwrite").parquet("s3://bucket/partitioned_output/")
