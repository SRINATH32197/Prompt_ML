PROBLEM STATEMENT : 

Implementing recursive joins (hierarchical org structures).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Implementing recursive joins (hierarchical org structures).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder.appName("RecursiveJoinOrgHierarchy").getOrCreate()

# Load org structure with employee_id and manager_id
org_df = spark.read.parquet("s3://bucket/org_structure/")

# Initialize level 0 (top-level managers)
level_0 = org_df.filter(col("manager_id").isNull()) \
                .select(col("employee_id").alias("root_id"),
                        col("employee_id"),
                        col("manager_id"),
                        col("name"),
                        col("title"),
                        col("department"),
                        col("level").alias("hierarchy_level"))

# Iteratively join to build hierarchy
result_df = level_0
for i in range(1, 10):
    next_level = result_df.alias("r").join(
        org_df.alias("o"),
        col("r.employee_id") == col("o.manager_id"),
        "inner"
    ).select(
        col("r.root_id"),
        col("o.employee_id"),
        col("o.manager_id"),
        col("o.name"),
        col("o.title"),
        col("o.department"),
        col("r.hierarchy_level") + 1
    ).withColumnRenamed("(r.hierarchy_level + 1)", "hierarchy_level")

    result_df = result_df.union(next_level)

# Write full hierarchy
result_df.write.mode("overwrite").parquet("s3://bucket/org_hierarchy_expanded/")
