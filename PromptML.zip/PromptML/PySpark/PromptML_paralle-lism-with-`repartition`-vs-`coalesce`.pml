PROBLEM STATEMENT : 

Controlling paralle lism with `repartition` vs. `coalesce`.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Controlling paralle lism with `repartition` vs. `coalesce`.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("ControlParallelism").getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Increase parallelism for wide transformations (e.g., joins, aggregations)
repartitioned_df = df.repartition(200, "partition_key")

# Decrease parallelism before writing to avoid small files
coalesced_df = repartitioned_df.coalesce(50)

# Write output
coalesced_df.write.mode("overwrite").parquet("s3://bucket/output/")
