PROBLEM STATEMENT : 

Incrementally ingesting data with watermarks.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Incrementally ingesting data with watermarks.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, TimestampType

spark = SparkSession.builder.appName("IncrementalIngestionWithWatermark").getOrCreate()

# Define schema with event timestamp
schema = StructType() \
    .add("event_id", StringType()) \
    .add("event_type", StringType()) \
    .add("event_time", TimestampType())

# Read streaming data from source (e.g., Kafka)
stream_df = spark.readStream.format("kafka") \
    .option("kafka.bootstrap.servers", "broker:9092") \
    .option("subscribe", "events_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse JSON payload
parsed_df = stream_df.selectExpr("CAST(value AS STRING) as json_str") \
    .withColumn("data", from_json(col("json_str"), schema)) \
    .select("data.*")

# Apply watermark for incremental ingestion
watermarked_df = parsed_df.withWatermark("event_time", "10 minutes")

# Write to sink with checkpointing
watermarked_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/incremental_output/") \
    .option("checkpointLocation", "s3://bucket/checkpoints/incremental/") \
    .outputMode("append") \
    .start()
