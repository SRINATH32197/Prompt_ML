PROBLEM STATEMENT : 

Using Delta log for lineage and audits.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Using Delta log for lineage and audits.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaLogLineageAudit") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Load Delta table history
history_df = spark.sql("""
    DESCRIBE HISTORY delta.`s3://bucket/delta_table/`
""")

# Extract lineage and audit metadata
audit_df = history_df.select(
    "version",
    "timestamp",
    "operation",
    "operationParameters",
    "userId",
    "userName",
    "notebook",
    "clusterId"
)

audit_df.show(truncate=False)
```