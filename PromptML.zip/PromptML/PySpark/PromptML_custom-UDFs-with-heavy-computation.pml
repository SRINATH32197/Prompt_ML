PROBLEM STATEMENT : 

Applying custom UDFs with heavy computation efficiently.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Applying custom UDFs with heavy computation efficiently.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, pandas_udf
from pyspark.sql.types import DoubleType
import numpy as np

spark = SparkSession.builder.appName("EfficientHeavyUDF").getOrCreate()

# Load data
df = spark.read.parquet("s3://bucket/input_data/")

# Define vectorized Pandas UDF for heavy computation
@pandas_udf(DoubleType())
def heavy_computation_udf(series):
    return series.apply(lambda x: np.log(np.sqrt(x**2 + 1)) * np.exp(x / 100))

# Apply UDF with partitioning
optimized_df = df.repartition("partition_key") \
                 .withColumn("computed_value", heavy_computation_udf(col("input_value")))

# Write output
optimized_df.write.mode("overwrite").parquet("s3://bucket/output_data/")
