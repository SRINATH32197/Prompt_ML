PROBLEM STATEMENT : 

Handling mixed encodings (UTF -8, ISO -8859 -1).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling mixed encodings (UTF -8, ISO -8859 -1).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
import chardet
import boto3

spark = SparkSession.builder.appName("MixedEncodingHandler").getOrCreate()

# S3 config
bucket = "bucket"
prefix = "data/"
s3 = boto3.client("s3")
response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

# Detect encoding using chardet
def detect_encoding(key):
    obj = s3.get_object(Bucket=bucket, Key=key)
    sample = obj["Body"].read(1024)
    return chardet.detect(sample)["encoding"]

# Filter and classify files
valid_keys = [obj["Key"] for obj in response.get("Contents", [])
              if obj["Key"].endswith(".csv") and not obj["Key"].split("/")[-1].startswith(("_", "."))]

# Read files with detected encoding
for key in valid_keys:
    encoding = detect_encoding(key)
    path = f"s3://{bucket}/{key}"
    df = spark.read.option("header", "true") \
                   .option("encoding", encoding) \
                   .csv(path)
    # process df as needed
