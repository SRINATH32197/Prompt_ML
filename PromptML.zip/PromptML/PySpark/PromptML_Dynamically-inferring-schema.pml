PROBLEM STATEMENT : 

Dynamically inferring schema for varying daily data dumps.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Dynamically inferring schema for varying daily data dumps.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import input_file_name

spark = SparkSession.builder.appName("DynamicSchemaInference").getOrCreate()

# Path to daily dumps
base_path = "s3://bucket/daily_dumps/"

# Read all files with schema inference
df = spark.read.option("inferSchema", "true") \
               .option("header", "true") \
               .csv(base_path)

# Tag source file for traceability
df = df.withColumn("source_file", input_file_name())

# Optional: unify schema by adding missing columns
expected_columns = ["id", "name", "timestamp", "status"]
for col_name in expected_columns:
    if col_name not in df.columns:
        df = df.withColumn(col_name, lit(None))
