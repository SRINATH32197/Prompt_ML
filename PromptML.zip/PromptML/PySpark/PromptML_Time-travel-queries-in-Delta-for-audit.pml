PROBLEM STATEMENT : 

Time travel queries in Delta for audit use cases.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Time travel queries in Delta for audit use cases.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaTimeTravelAudit") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Load Delta table at specific version
version_df = spark.read \
    .format("delta") \
    .option("versionAsOf", 42) \
    .load("s3://bucket/delta_table/")

# Load Delta table at specific timestamp
timestamp_df = spark.read \
    .format("delta") \
    .option("timestampAsOf", "2025-09-15T10:00:00") \
    .load("s3://bucket/delta_table/")

# Audit logic example
audit_df = version_df.join(
    timestamp_df,
    on="record_id",
    how="outer"
).selectExpr(
    "record_id",
    "version_df.*",
    "timestamp_df.*"
)
```