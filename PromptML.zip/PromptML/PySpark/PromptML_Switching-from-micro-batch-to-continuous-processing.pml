PROBLEM STATEMENT : 

Switching from micro -batch to continuous processing.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Switching from micro -batch to continuous processing.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("ContinuousProcessingMode") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Read from Kafka
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Write using continuous processing mode
parsed_df.writeStream \
    .format("console") \
    .option("checkpointLocation", "s3://bucket/continuous_checkpoint/") \
    .option("truncate", "false") \
    .trigger(continuous="1 second") \
    .start() \
    .awaitTermination()
