PROBLEM STATEMENT : 

Pivoting large -scale datasets dynam ically.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Pivoting large -scale datasets dynam ically.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import collect_list, first
from pyspark.sql import functions as F

spark = SparkSession.builder.appName("DynamicPivot").getOrCreate()

# Load data
df = spark.read.parquet("s3://bucket/metrics_data/")

# Extract distinct pivot values
pivot_values = [row["metric_type"] for row in df.select("metric_type").distinct().collect()]

# Perform dynamic pivot
pivot_df = df.groupBy("entity_id").pivot("metric_type", pivot_values).agg(first("metric_value"))

# Write output
pivot_df.write.mode("overwrite").parquet("s3://bucket/pivoted_output/")
