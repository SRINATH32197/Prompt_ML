PROBLEM STATEMENT : 

Preventing data skew in joins by sampling.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Preventing data skew in joins by sampling.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, rand

spark = SparkSession.builder.appName("PreventSkewBySampling").getOrCreate()

# Load large and small datasets
large_df = spark.read.parquet("s3://bucket/large_table/")
small_df = spark.read.parquet("s3://bucket/small_table/")

# Sample large dataset to estimate skew
sampled_df = large_df.sample(False, 0.01)
skew_keys = sampled_df.groupBy("join_key").count() \
                      .filter("count > 1000") \
                      .select("join_key") \
                      .rdd.flatMap(lambda x: x).collect()

# Filter out skewed keys from large_df
non_skew_df = large_df.filter(~col("join_key").isin(skew_keys))

# Join non-skewed portion normally
joined_non_skew = non_skew_df.join(small_df, "join_key", "inner")

# Handle skewed keys separately with salting
skew_df = large_df.filter(col("join_key").isin(skew_keys)) \
                  .withColumn("salt", (rand() * 10).cast("int"))

salted_small = small_df.filter(col("join_key").isin(skew_keys)) \
                       .crossJoin(spark.range(0, 10).toDF("salt"))

joined_skew = skew_df.join(
    salted_small,
    (skew_df["join_key"] == salted_small["join_key"]) &
    (skew_df["salt"] == salted_small["salt"]),
    "inner"
)

# Union both results
final_df = joined_non_skew.unionByName(joined_skew)

# Write output
final_df.write.mode("overwrite").parquet("s3://bucket/skew_aware_join_output/")
