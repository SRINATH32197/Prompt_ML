PROBLEM STATEMENT : 

Monitoring and alerting for streaming lag.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Monitoring and al erting for streaming lag.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, unix_timestamp, current_timestamp, expr

spark = SparkSession.builder \
    .appName("StreamingLagMonitoring") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Read from Kafka
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Compute lag in seconds
lag_df = parsed_df.withColumn("lag_seconds", 
    unix_timestamp(current_timestamp()) - unix_timestamp(col("timestamp"))
)

# Filter high-lag events
alert_df = lag_df.filter(col("lag_seconds") > 300)

# Write alerts to external sink (e.g., Kafka, monitoring system)
alert_df.selectExpr("CAST(key AS STRING) AS key", "CAST(lag_seconds AS STRING) AS value") \
    .writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("topic", "streaming_lag_alerts") \
    .option("checkpointLocation", "s3://bucket/lag_alerts_checkpoint/") \
    .outputMode("update") \
    .start() \
    .awaitTermination()
