PROBLEM STATEMENT : 

Filtering datasets with complex regular expressions.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Filtering datasets with complex regular expressions.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder.appName("RegexFiltering").getOrCreate()

# Load dataset
df = spark.read.parquet("s3://bucket/text_data/")

# Define complex regex pattern (e.g., extract valid email addresses with specific domain)
pattern = r"^[a-zA-Z0-9._%+-]+@example\.com$"

# Filter using regex
filtered_df = df.filter(col("email").rlike(pattern))

# Write output
filtered_df.write.mode("overwrite").parquet("s3://bucket/filtered_output/")
