PROBLEM STATEMENT : 

Optimizing skewed joins (salting, broadcasting).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Optimizing skewed joins (salting, broadcasting).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import rand, broadcast

spark = SparkSession.builder.appName("OptimizeSkewedJoin").getOrCreate()

# Load datasets
large_df = spark.read.parquet("s3://bucket/large_dataset")
small_df = spark.read.parquet("s3://bucket/small_dataset")

# SALTING STRATEGY
salted_large = large_df.withColumn("salt", (rand() * 10).cast("int"))
salted_small = small_df.crossJoin(spark.range(0, 10).toDF("salt"))
salted_join = salted_large.join(salted_small, ["join_key", "salt"], "inner")

# BROADCAST STRATEGY (if small_df is small enough)
broadcast_join = large_df.join(broadcast(small_df), "join_key", "inner")
