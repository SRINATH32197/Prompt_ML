PROBLEM STATEMENT : 

Caching vs. persisting with proper storage levels.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Caching vs. persisting with proper storage levels.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark import StorageLevel

spark = SparkSession.builder.appName("CachingVsPersisting").getOrCreate()

# Load large dataset
df = spark.read.parquet("s3://bucket/large_dataset/")

# Cache when default MEMORY_AND_DISK is sufficient
cached_df = df.cache()

# Persist with custom storage level when memory is constrained or disk-only is preferred
persisted_df = df.persist(StorageLevel.DISK_ONLY)

# Trigger actions to materialize cache/persist
cached_df.count()
persisted_df.count()

# Unpersist when no longer needed
cached_df.unpersist()
persisted_df.unpersist()
