PROBLEM STATEMENT : 

Schema evolution in Parquet/Avro datasets.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Schema evolution in Parquet/Avro datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import lit

spark = SparkSession.builder.appName("SchemaEvolutionHandler").getOrCreate()

# Read multiple Parquet files with evolving schema
df = spark.read.option("mergeSchema", "true").parquet("s3://bucket/path/")

# Optional: add missing columns with default values
expected_columns = ["id", "name", "timestamp", "status"]
for col_name in expected_columns:
    if col_name not in df.columns:
        df = df.withColumn(col_name, lit(None))

# Write back with schema evolution support
df.write.option("mergeSchema", "true").mode("append").parquet("s3://bucket/output/")
