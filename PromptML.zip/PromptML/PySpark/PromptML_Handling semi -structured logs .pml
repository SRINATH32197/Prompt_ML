PROBLEM STATEMENT : 

Handling semi -structured logs (n ested JSON inside a CSV column).


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Handling semi -structured logs (n ested JSON inside a CSV column).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT : 

from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, IntegerType, DoubleType

spark = SparkSession.builder.appName("NestedJSONInCSV").getOrCreate()

# Define schema for nested JSON
json_schema = StructType() \
    .add("event_type", StringType()) \
    .add("user_id", StringType()) \
    .add("duration", DoubleType()) \
    .add("metadata", StructType()
         .add("ip", StringType())
         .add("device", StringType()))

# Read CSV with nested JSON column
df = spark.read.option("header", "true").csv("s3://bucket/logs/semi_structured.csv")

# Parse JSON column
parsed_df = df.withColumn("json_data", from_json(col("log_payload"), json_schema))

# Flatten nested fields
flattened_df = parsed_df.select(
    col("timestamp"),
    col("json_data.event_type"),
    col("json_data.user_id"),
    col("json_data.duration"),
    col("json_data.metadata.ip"),
    col("json_data.metadata.device")
)
