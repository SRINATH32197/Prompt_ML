PROBLEM STATEMENT : 

Implementing idempotent writes for streaming sinks.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Implementing idempotent writes for streaming sinks.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

spark = SparkSession.builder \
    .appName("IdempotentStreamingWrites") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

# Read from Kafka
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Deduplicate using watermark and unique key
dedup_df = parsed_df \
    .withWatermark("timestamp", "10 minutes") \
    .dropDuplicates(["key", "timestamp"])

# Write to Delta Lake with merge semantics for idempotency
dedup_df.writeStream \
    .format("delta") \
    .outputMode("append") \
    .option("checkpointLocation", "s3://bucket/idempotent_checkpoint/") \
    .start("s3://bucket/idempotent_output/") \
    .awaitTermination()
