PROBLEM STATEMENT : 

Deduplicating records with fuzzy matching.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Deduplicating records with fuzzy matching.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, levenshtein, row_number
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("FuzzyDeduplication").getOrCreate()

# Load data
df = spark.read.parquet("s3://bucket/raw_records/")

# Self join with fuzzy condition
fuzzy_join = df.alias("a").join(
    df.alias("b"),
    (levenshtein(col("a.name"), col("b.name")) <= 2) &
    (col("a.id") != col("b.id")),
    "inner"
).select(
    col("a.id").alias("id_a"),
    col("b.id").alias("id_b"),
    col("a.name").alias("name_a"),
    col("b.name").alias("name_b"),
    levenshtein(col("a.name"), col("b.name")).alias("distance")
)

# Select best representative using window
window_spec = Window.partitionBy("name_a").orderBy("distance")
ranked = fuzzy_join.withColumn("rank", row_number().over(window_spec)) \
                   .filter(col("rank") == 1)

# Filter original records to keep only one per fuzzy group
deduped_ids = ranked.select("id_a").distinct()
deduped_df = df.join(deduped_ids, df["id"] == deduped_ids["id_a"], "inner").drop("id_a")

# process deduped_df as needed
