PROBLEM STATEMENT : 

Splitting a single column into multiple n ormalized tables.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Splitting a single column into multiple n ormalized tables.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col, monotonically_increasing_id

spark = SparkSession.builder.appName("ColumnNormalization").getOrCreate()

# Load raw data
df = spark.read.parquet("s3://bucket/raw_data/")

# Assume 'full_address' column contains "region|country|city"
split_df = df.withColumn("region", split(col("full_address"), "\\|")[0]) \
             .withColumn("country", split(col("full_address"), "\\|")[1]) \
             .withColumn("city", split(col("full_address"), "\\|")[2]) \
             .withColumn("address_id", monotonically_increasing_id())

# Create normalized tables
region_table = split_df.select("address_id", "region").dropDuplicates(["region"])
country_table = split_df.select("address_id", "country").dropDuplicates(["country"])
city_table = split_df.select("address_id", "city").dropDuplicates(["city"])
fact_table = split_df.select("address_id", "region", "country", "city", "other_columns...")

# Write normalized tables
region_table.write.mode("overwrite").parquet("s3://bucket/normalized/region/")
country_table.write.mode("overwrite").parquet("s3://bucket/normalized/country/")
city_table.write.mode("overwrite").parquet("s3://bucket/normalized/city/")
fact_table.write.mode("overwrite").parquet("s3://bucket/normalized/fact/")
