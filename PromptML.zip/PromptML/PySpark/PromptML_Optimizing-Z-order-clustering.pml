PROBLEM STATEMENT : 

Optimizing Z -order clustering for Delta ta bles.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Optimizing Z -order clustering for Delta ta bles.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DeltaZOrderOptimization") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Load Delta table
df = spark.read.format("delta").load("s3://bucket/delta_table/")

# Rewrite with Z-Order clustering on high-cardinality filter columns
df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .option("dataChange", "false") \
    .save("s3://bucket/delta_table/")

# Optimize with Z-Order
spark.sql("""
    OPTIMIZE delta.`s3://bucket/delta_table/`
    ZORDER BY (user_id, event_ts)
""")


