PROBLEM STATEMENT : 

Implementing exactly -once processing in Spark Structured Streaming.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Implementing exactly -once processing in Spark Structured Streaming.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

spark = SparkSession.builder \
    .appName("ExactlyOnceProcessing") \
    .config("spark.sql.streaming.forceDeleteTempCheckpointLocation", "true") \
    .getOrCreate()

# Read from Kafka with checkpointing
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "topic_name") \
    .option("startingOffsets", "latest") \
    .load()

# Parse Kafka payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

# Deduplicate using watermark and key
dedup_df = parsed_df \
    .withWatermark("timestamp", "10 minutes") \
    .dropDuplicates(["key", "timestamp"])

# Write to idempotent sink with checkpointing
dedup_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/exactly_once_output/") \
    .option("checkpointLocation", "s3://bucket/exactly_once_checkpoint/") \
    .outputMode("append") \
    .start() \
    .awaitTermination()
