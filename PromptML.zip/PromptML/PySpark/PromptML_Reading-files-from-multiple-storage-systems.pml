PROBLEM STATEMENT : 

Reading files from multiple storage systems (S3, HDFS, ADLS) in one job.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Readi ng files from multiple storage systems (S3, HDFS, ADLS) in one job.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("MultiStorageRead") \
    .config("fs.s3a.access.key", "YOUR_S3_ACCESS_KEY") \
    .config("fs.s3a.secret.key", "YOUR_S3_SECRET_KEY") \
    .config("fs.azure.account.key.YOUR_ADLS_ACCOUNT.blob.core.windows.net", "YOUR_ADLS_KEY") \
    .getOrCreate()

# Read from S3
s3_df = spark.read.parquet("s3a://bucket/path/")

# Read from HDFS
hdfs_df = spark.read.parquet("hdfs://namenode:8020/path/")

# Read from ADLS
adls_df = spark.read.parquet("wasbs://container@YOUR_ADLS_ACCOUNT.blob.core.windows.net/path/")

# Union all sources
combined_df = s3_df.unionByName(hdfs_df, allowMissingColumns=True) \
                   .unionByName(adls_df, allowMissingColumns=True)
