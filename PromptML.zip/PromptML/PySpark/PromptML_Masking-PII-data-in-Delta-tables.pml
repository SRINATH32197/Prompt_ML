PROBLEM STATEMENT : 

Masking PII data in Delta tables.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Masking PII data in Delta tables.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import sha2, col, lit

spark = SparkSession.builder \
    .appName("DeltaPIIMasking") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# Load Delta table
df = spark.read.format("delta").load("s3://bucket/source_table/")

# Mask PII columns
masked_df = df.withColumn("email", sha2(col("email"), 256)) \
              .withColumn("phone", lit("**********")) \
              .withColumn("ssn", lit("XXX-XX-XXXX"))

# Write masked data to secure Delta table
masked_df.write \
    .format("delta") \
    .mode("overwrite") \
    .save("s3://bucket/masked_table/")
