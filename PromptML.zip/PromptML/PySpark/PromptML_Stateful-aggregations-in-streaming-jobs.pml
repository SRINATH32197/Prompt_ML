PROBLEM STATEMENT : 

Stateful aggregations in streaming jobs.


.........................................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Stateful aggregations in streaming jobs.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT :

from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

spark = SparkSession.builder.appName("StatefulAggregationStreaming").getOrCreate()

# Read streaming source
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker1:9092") \
    .option("subscribe", "event_topic") \
    .option("startingOffsets", "latest") \
    .load()

# Parse payload
parsed_df = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)")

# Apply watermark and stateful aggregation
aggregated_df = parsed_df \
    .withWatermark("timestamp", "10 minutes") \
    .groupBy(expr("key"), expr("window(timestamp, '5 minutes')")) \
    .count()

# Write output
aggregated_df.writeStream \
    .format("parquet") \
    .option("path", "s3://bucket/stateful_aggregation_output/") \
    .option("checkpointLocation", "s3://bucket/stateful_aggregation_checkpoint/") \
    .outputMode("append") \
    .start() \
    .awaitTermination()
