PROBLEM STATEMENT : 

Optimizing broadcast joins with large broadcast data.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Optimizing broadcast joins with large broadcast data.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions.broadcast

object OptimizedBroadcastJoin {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("OptimizedBroadcastJoin")
      .config("spark.sql.autoBroadcastJoinThreshold", "-1")
      .getOrCreate()

    val largeDF = spark.read.parquet("s3://bucket/large_dataset/")
    val broadcastDF = spark.read.parquet("s3://bucket/broadcast_dataset/")

    val optimizedBroadcastDF = broadcastDF.repartition(100).cache()

    val resultDF = largeDF.join(broadcast(optimizedBroadcastDF), Seq("join_key"), "inner")

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/broadcast_join_result")

    spark.stop()
  }
}

