PROBLEM STATEMENT : 

Estimating optimal partition size in bytes.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Estimating optimal partition size in bytes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, Row}
import scala.math._

object EstimatePartitionSize {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("EstimatePartitionSize")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_dataset/")

    val totalSize = df.rdd.map(row => row.toString().getBytes.length.toLong).reduce(_ + _)

    val targetPartitionSize = 128 * 1024 * 1024 // 128 MB
    val optimalPartitions = max(1, ceil(totalSize.toDouble / targetPartitionSize).toInt)

    val repartitionedDF = df.repartition(optimalPartitions)

    repartitionedDF.write.mode("overwrite").parquet("s3://bucket/output/partitioned_estimate")

    spark.stop()
  }
}
