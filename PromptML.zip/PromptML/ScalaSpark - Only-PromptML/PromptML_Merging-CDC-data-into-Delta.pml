PROBLEM STATEMENT : 

Merging CDC data into Delta with `MERGE INTO`.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Merging CDC data into Delta with `MERGE INTO`.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import org.apache.spark.sql.functions._

object MergeCDCIntoDelta {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("MergeCDCIntoDelta")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val cdcDF = spark.read.format("json").load("s3://bucket/cdc_data/")
    cdcDF.createOrReplaceTempView("cdc_view")

    val targetTable = DeltaTable.forPath(spark, "s3://bucket/delta_table/")

    targetTable.as("target")
      .merge(
        spark.sql("SELECT * FROM cdc_view").as("source"),
        "target.id = source.id"
      )
      .whenMatched()
      .updateExpr(Map(
        "name" -> "source.name",
        "value" -> "source.value",
        "updated_at" -> "current_timestamp()"
      ))
      .whenNotMatched()
      .insertExpr(Map(
        "id" -> "source.id",
        "name" -> "source.name",
        "value" -> "source.value",
        "updated_at" -> "current_timestamp()"
      ))
      .execute()
  }
}
```
