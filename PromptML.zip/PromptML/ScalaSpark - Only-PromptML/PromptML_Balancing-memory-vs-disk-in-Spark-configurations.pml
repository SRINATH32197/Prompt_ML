PROBLEM STATEMENT : 

Balancing memory vs. disk in Spark configurations.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Balancing memory vs. disk in Spark configurations.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.storage.StorageLevel

object BalanceMemoryDisk {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("BalanceMemoryDisk")
      .config("spark.memory.fraction", "0.6")
      .config("spark.memory.storageFraction", "0.3")
      .config("spark.sql.shuffle.partitions", "200")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_dataset/")
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    val resultDF = df.filter("value > 100")
      .groupBy("category")
      .count()

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/memory_disk_balanced")

    spark.stop()
  }
}
