PROBLEM STATEMENT : 

Implementing file versioning in data lake ingestion.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing file versioning in data lake ingestion.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime

object FileVersioningIngestion {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("FileVersioningIngestion")
      .getOrCreate()

    val df = spark.read.option("header", "true").csv("s3://bucket/incoming_data/")

    val version = DateTimeFormatter.ofPattern("vyyyyMMddHHmmss").format(LocalDateTime.now())

    df.write.mode("overwrite").parquet(s"s3://bucket/data_lake/versions/$version/")
    df.write.mode("overwrite").parquet("s3://bucket/data_lake/latest/")

    spark.stop()
  }
}
