PROBLEM STATEMENT : 

Dynamically inferring schema for varying daily data dumps.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Dynamically inferring schema for varying daily data dumps.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object DynamicSchemaInference {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DynamicSchemaInference")
      .getOrCreate()

    val dailyDF = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv("s3://bucket/daily_dumps/*")

    dailyDF.write.mode("overwrite").parquet("s3://bucket/output/unified_daily_data")

    spark.stop()
  }
}
