PROBLEM STATEMENT : 

Handling late -arriving data in event streams.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling late -arriving data in event streams.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT: 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object LateArrivingEventStream {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("LateArrivingEventStream")
      .getOrCreate()

    val df = spark.readStream
      .format("parquet")
      .option("path", "s3://bucket/event_stream/")
      .option("maxFilesPerTrigger", 1)
      .load()

    val watermarkedDF = df.withWatermark("event_time", "15 minutes")

    val aggregatedDF = watermarkedDF.groupBy(
      expr("window(event_time, '10 minutes')"),
      col("user_id")
    ).count()

    aggregatedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/late_event_handling")
      .option("checkpointLocation", "s3://bucket/checkpoints/late_event_handling")
      .outputMode("append")
      .start()
      .awaitTermination()
  }
}
