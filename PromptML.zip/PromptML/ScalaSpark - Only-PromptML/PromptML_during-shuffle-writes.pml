PROBLEM STATEMENT : 

during shuffle writes.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        during shuffle writes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :


import org.apache.spark.sql.{SparkSession, DataFrame}

object OptimizeShuffleWrites {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("OptimizeShuffleWrites")
      .config("spark.sql.shuffle.partitions", "200")
      .config("spark.shuffle.compress", "true")
      .config("spark.shuffle.spill.compress", "true")
      .config("spark.shuffle.file.buffer", "64k")
      .config("spark.reducer.maxSizeInFlight", "48m")
      .config("spark.shuffle.sort.bypassMergeThreshold", "200")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_shuffle_write_data/")

    val resultDF = df.groupBy("category").count()

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/shuffle_write_optimized")

    spark.stop()
  }
}
