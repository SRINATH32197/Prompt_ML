PROBLEM STATEMENT : 

Auto-detecting file compression (gzip, snappy, bzip2).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Auto-detecting file compression (gzip, snappy, bzip2).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import scala.collection.JavaConverters._
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.ListObjectsV2Request

object AutoDetectCompression {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AutoDetectCompression")
      .getOrCreate()

    val s3Client = AmazonS3ClientBuilder.defaultClient()
    val bucket = "bucket"
    val prefix = "compressed_data/"
    val request = new ListObjectsV2Request().withBucketName(bucket).withPrefix(prefix)
    val result = s3Client.listObjectsV2(request)

    val compressionMap = Map(
      ".gz" -> "gzip",
      ".snappy" -> "snappy",
      ".bz2" -> "bzip2"
    )

    def detectCompression(key: String): Option[String] = {
      compressionMap.find { case (ext, _) => key.endsWith(ext) }.map(_._2)
    }

    val files = result.getObjectSummaries.asScala
      .map(_.getKey)
      .flatMap(key => detectCompression(key).map(codec => (key, codec)))
      .map { case (key, codec) => (s"s3://$bucket/$key", codec) }

    files.foreach { case (path, codec) =>
      val df = spark.read.option("compression", codec).csv(path)
      df.write.mode("append").parquet("s3://bucket/output/decoded_data")
    }

    spark.stop()
  }
}
