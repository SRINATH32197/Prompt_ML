PROBLEM STATEMENT : 

Auto-merging small Parquet files into larger ones.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Auto-merging small Parquet files into larger ones.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object MergeSmallParquetFiles {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("MergeSmallParquetFiles")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/small_parquet_files/")
    val mergedDF = df.coalesce(10)

    mergedDF.write.mode("overwrite").parquet("s3://bucket/output/merged_parquet")

    spark.stop()
  }
}
