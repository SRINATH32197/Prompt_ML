PROBLEM STATEMENT : 

Time travel queries in Delta for audit use cases.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Time travel queries in Delta for audit use cases.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession

object DeltaTimeTravelAudit {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DeltaTimeTravelAudit")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val versionDF = spark.read
      .format("delta")
      .option("versionAsOf", 42)
      .load("s3://bucket/delta_table/")

    val timestampDF = spark.read
      .format("delta")
      .option("timestampAsOf", "2025-09-15T10:00:00")
      .load("s3://bucket/delta_table/")

    versionDF.createOrReplaceTempView("audit_version")
    timestampDF.createOrReplaceTempView("audit_timestamp")

    spark.sql("SELECT * FROM audit_version WHERE user_id = 'U123'").show()
    spark.sql("SELECT * FROM audit_timestamp WHERE user_id = 'U123'").show()
  }
}
```
