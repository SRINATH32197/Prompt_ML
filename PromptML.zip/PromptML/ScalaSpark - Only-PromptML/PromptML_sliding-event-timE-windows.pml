PROBLEM STATEMENT : 

Implementing sliding event -time windows.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing sliding event -time windows.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object SlidingEventTimeWindow {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SlidingEventTimeWindow")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val streamDF = spark.readStream
      .format("json")
      .option("maxFilesPerTrigger", 10)
      .load("s3://bucket/streaming_input/")
      .withColumn("event_ts", col("timestamp").cast("timestamp"))

    val windowedDF = streamDF
      .withWatermark("event_ts", "10 minutes")
      .groupBy(window(col("event_ts"), "15 minutes", "5 minutes"))
      .count()

    windowedDF.writeStream
      .format("delta")
      .outputMode("append")
      .option("checkpointLocation", "s3://bucket/checkpoints/sliding_window/")
      .start("s3://bucket/delta_output/")
      .awaitTermination()
  }
}
