PROBLEM STATEMENT : 

Handling Kafka offset management manually.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling Kafka offset management manually.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT: 

import org.apache.spark.sql.{SparkSession, DataFrame}

object KafkaManualOffsetManagement {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("KafkaManualOffsetManagement")
      .config("spark.sql.streaming.forceDeleteTempCheckpointLocation", "true")
      .getOrCreate()

    val kafkaBootstrapServers = "broker1:9092,broker2:9092"
    val topic = "events"
    val startingOffsets = """{"events":{"0":12345,"1":67890}}""" // manual offsets

    val df = spark.read
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaBootstrapServers)
      .option("subscribe", topic)
      .option("startingOffsets", startingOffsets)
      .load()

    val parsedDF = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

    parsedDF.write.mode("overwrite").parquet("s3://bucket/output/kafka_manual_offsets")

    spark.stop()
  }
}
