PROBLEM STATEMENT : 

Scaling Spark streaming jobs horizontally.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Scaling Spark streaming jobs horizontally.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object ScaleStreamingHorizontally {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ScaleStreamingHorizontally")
      .config("spark.sql.shuffle.partitions", "400")
      .config("spark.streaming.concurrentJobs", "4")
      .config("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider")
      .config("spark.sql.streaming.stateStore.rocksdb.compactOnCommit", "true")
      .config("spark.sql.streaming.stateStore.rocksdb.writeBufferSizeMB", "64")
      .getOrCreate()

    val df = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "broker1:9092")
      .option("subscribe", "events")
      .option("startingOffsets", "latest")
      .load()

    val parsedDF = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

    parsedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/scaled_streaming/")
      .option("checkpointLocation", "s3://bucket/checkpoints/scaled_streaming/")
      .outputMode("append")
      .start()
      .awaitTermination()

    spark.stop()
  }
}

