PROBLEM STATEMENT : 

Replaying data from a checkpoint directory.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Replaying data from a checkpoint directory.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object ReplayFromCheckpoint {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ReplayFromCheckpoint")
      .getOrCreate()

    val streamingDF = spark.readStream
      .format("parquet")
      .option("path", "s3://bucket/output/streaming_data/")
      .load()

    val resultDF = streamingDF.selectExpr("key", "value", "timestamp")

    resultDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/replayed_data/")
      .option("checkpointLocation", "s3://bucket/checkpoints/streaming_job/")
      .outputMode("append")
      .start()
      .awaitTermination()

    spark.stop()
  }
}


