PROBLEM STATEMENT : 

“as-of” joins for temporal datasets.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        “as-of” joins for temporal datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object AsOfJoinTemporal {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AsOfJoinTemporal")
      .getOrCreate()

    val eventsDF = spark.read.parquet("s3://bucket/events/")
    val referenceDF = spark.read.parquet("s3://bucket/reference/")

    val combinedDF = eventsDF.join(referenceDF, Seq("entity_id"), "left")
      .filter(col("reference_time") <= col("event_time"))

    val windowSpec = Window.partitionBy("entity_id", "event_time")
      .orderBy(col("reference_time").desc)

    val asofDF = combinedDF.withColumn("latest_value", last("reference_value").over(windowSpec))
      .select("entity_id", "event_time", "latest_value")

    asofDF.write.mode("overwrite").parquet("s3://bucket/output/asof_join_result")

    spark.stop()
  }
}
