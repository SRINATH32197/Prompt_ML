PROBLEM STATEMENT : 

Performing sliding window calculations for time -series data. 19 Handling


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Performing sliding window calculations for time -series data. 19 Handling
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object SlidingWindowTimeSeries {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SlidingWindowTimeSeries")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/time_series_data/")

    val windowSpec = Window.partitionBy("entity_id")
      .orderBy("event_time")
      .rowsBetween(-18, 0)

    val resultDF = df.withColumn("moving_avg", avg("value").over(windowSpec))

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/sliding_window_result")

    spark.stop()
  }
}
