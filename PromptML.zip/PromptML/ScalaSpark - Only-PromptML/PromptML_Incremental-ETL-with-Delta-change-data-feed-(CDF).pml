PROBLEM STATEMENT : 

Incremental ETL with Delta change data feed (CDF).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Incremental ETL with Delta change data feed (CDF).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.SparkSession

object DeltaCDFIncrementalETL {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DeltaCDFIncrementalETL")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val cdfDF = spark.read.format("delta")
      .option("readChangeData", "true")
      .option("startingVersion", 100)
      .option("endingVersion", 105)
      .table("spark_catalog.default.source_table")

    val filteredDF = cdfDF.filter("change_type IN ('insert', 'update_postimage')")

    filteredDF.write.format("delta")
      .mode("append")
      .save("s3://bucket/target_table/")
  }
}
