PROBLEM STATEMENT : 

Adaptive Query Execution (AQE) tuning for joins. 20 Handling spill -over


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Adaptive Query Execution (AQE) tuning for joins. 20 Handling spill -over
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object AQEJoinSpillHandling {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AQEJoinSpillHandling")
      .config("spark.sql.adaptive.enabled", "true")
      .config("spark.sql.adaptive.skewJoin.enabled", "true")
      .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
      .config("spark.sql.adaptive.localShuffleReader.enabled", "true")
      .config("spark.sql.adaptive.advisoryPartitionSizeInBytes", (64 * 1024 * 1024).toString)
      .config("spark.sql.shuffle.partitions", "200")
      .config("spark.sql.autoBroadcastJoinThreshold", "-1")
      .config("spark.sql.join.preferSortMergeJoin", "true")
      .config("spark.sql.sortMerge.joinExec.buffer.spill.threshold", (32 * 1024 * 1024).toString)
      .getOrCreate()

    val leftDF = spark.read.parquet("s3://bucket/left_dataset/")
    val rightDF = spark.read.parquet("s3://bucket/right_dataset/")

    val joinedDF = leftDF.join(rightDF, Seq("join_key"), "inner")

    joinedDF.write.mode("overwrite").parquet("s3://bucket/output/aqe_spill_handled")

    spark.stop()
  }
}

