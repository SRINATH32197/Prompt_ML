PROBLEM STATEMENT : 

Detecting and ignoring hidden/system files (`_SUCCESS`, `.crc`).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Detecting and ignoring hidden/system files (`_SUCCESS`, `.crc`).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import scala.collection.JavaConverters._
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.ListObjectsV2Request

object IgnoreHiddenSystemFiles {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("IgnoreHiddenSystemFiles")
      .getOrCreate()

    val s3Client = AmazonS3ClientBuilder.defaultClient()
    val bucket = "bucket"
    val prefix = "data/"
    val request = new ListObjectsV2Request().withBucketName(bucket).withPrefix(prefix)
    val result = s3Client.listObjectsV2(request)

    val dataFiles = result.getObjectSummaries.asScala
      .map(_.getKey)
      .filterNot(key => key.matches("(^_|^\\.|/_|/\\.)"))
      .map(key => s"s3://$bucket/$key")
      .toArray

    val df = spark.read.parquet(dataFiles: _*)
    df.write.mode("overwrite").parquet("s3://bucket/output/cleaned_data")

    spark.stop()
  }
}
