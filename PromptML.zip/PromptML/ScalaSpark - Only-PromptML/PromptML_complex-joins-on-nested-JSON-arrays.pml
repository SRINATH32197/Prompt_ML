PROBLEM STATEMENT : 

Performing complex joins on nested JSON arrays.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Performing complex joins on nested JSON arrays.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object NestedJSONArrayJoin {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("NestedJSONArrayJoin")
      .getOrCreate()

    val ordersDF = spark.read.option("multiLine", "true").json("s3://bucket/orders.json")
    val productsDF = spark.read.json("s3://bucket/products.json")

    val explodedOrders = ordersDF.withColumn("item", explode(col("items")))

    val flattenedOrders = explodedOrders.select(
      col("order_id"),
      col("customer_id"),
      col("item.product_id").alias("product_id"),
      col("item.quantity").alias("quantity")
    )

    val joinedDF = flattenedOrders.join(productsDF, Seq("product_id"), "inner")

    joinedDF.write.mode("overwrite").parquet("s3://bucket/output/joined_orders_products")

    spark.stop()
  }
}
