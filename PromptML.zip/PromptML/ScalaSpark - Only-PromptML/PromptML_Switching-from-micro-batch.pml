PROBLEM STATEMENT : 

Switching from micro -batch to continuous processing.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Switching from micro -batch to continuous processing.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession

object ContinuousProcessingSwitch {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ContinuousProcessingSwitch")
      .config("spark.sql.streaming.unsupportedOperationCheck", "false")
      .getOrCreate()

    val streamDF = spark.readStream
      .format("rate")
      .option("rowsPerSecond", 1000)
      .load()

    streamDF.writeStream
      .format("console")
      .outputMode("append")
      .trigger(org.apache.spark.sql.streaming.Trigger.Continuous("1 second"))
      .start()
      .awaitTermination()
  }
}


