PROBLEM STATEMENT : 

Joining fact and slowly changing dimension (SCD Type 2).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Joining fact and slowly changing dimension (SCD Type 2).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets 
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object JoinFactWithSCDType2 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("JoinFactWithSCDType2")
      .getOrCreate()

    val factDF = spark.read.parquet("s3://bucket/fact_table/")
    val dimDF = spark.read.parquet("s3://bucket/scd_type2_dimension/")

    val joinedDF = factDF.join(
      dimDF,
      factDF("dim_id") === dimDF("dim_id") &&
      factDF("event_date") >= dimDF("effective_date") &&
      factDF("event_date") < dimDF("end_date"),
      "left"
    )

    joinedDF.write.mode("overwrite").parquet("s3://bucket/output/fact_scd_joined")

    spark.stop()
  }
}

