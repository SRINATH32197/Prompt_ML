PROBLEM STATEMENT : 

Benchmarking Spark jobs across cluster sizes.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Benchmarking Spark jobs across cluster sizes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import scala.compat.Platform

object BenchmarkClusterSize {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("BenchmarkClusterSize")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/benchmark_input/")

    val startTime = Platform.currentTime

    val resultDF = df.filter("value > 100")
      .groupBy("category")
      .agg(Map("value" -> "avg", "id" -> "count"))

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/benchmark_result")

    val endTime = Platform.currentTime
    val duration = (endTime - startTime) / 1000.0
    println(s"Execution time: $duration seconds")

    spark.stop()
  }
}
