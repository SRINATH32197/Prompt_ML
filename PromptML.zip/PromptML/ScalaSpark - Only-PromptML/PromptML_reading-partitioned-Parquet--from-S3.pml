PROBLEM STATEMENT : 

Efficiently reading partitioned Parquet files from S3.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Efficiently reading partitioned Parquet files from S3.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object EfficientParquetRead {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("EfficientParquetRead")
      .getOrCreate()

    val df = spark.read
      .option("basePath", "s3://bucket/parquet_data/")
      .parquet("s3://bucket/parquet_data/region=IN/year=2025/")

    val filteredDF = df.filter("region = 'IN' AND year = 2025")

    filteredDF.write.mode("overwrite").parquet("s3://bucket/output/filtered_parquet")

    spark.stop()
  }
}
