PROBLEM STATEMENT : 

Pivoting large -scale datasets dynam ically.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Pivoting large -scale datasets dynam ically.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object DynamicPivotLargeScale {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DynamicPivotLargeScale")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/metrics_data/")

    val pivotKeys = df.select("metric_type").distinct().collect().map(_.getString(0))

    val pivotedDF = df.groupBy("entity_id")
      .pivot("metric_type", pivotKeys)
      .agg(first("metric_value"))

    pivotedDF.write.mode("overwrite").parquet("s3://bucket/output/dynamic_pivot")

    spark.stop()
  }
}
