PROBLEM STATEMENT : 

Implementing GDPR “right to be forgotten” deletions.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing GDPR “right to be forgotten” deletions.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.SparkSession
import io.delta.tables._

object GDPRRightToBeForgotten {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("GDPRRightToBeForgotten")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val deletionDF = spark.read.format("json").load("s3://bucket/gdpr_deletion_requests/")
    deletionDF.createOrReplaceTempView("deletion_requests")

    val deltaTable = DeltaTable.forPath(spark, "s3://bucket/delta_table/")

    deltaTable.as("target")
      .delete("target.user_id IN (SELECT user_id FROM deletion_requests)")
  }
}
