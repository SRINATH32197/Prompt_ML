PROBLEM STATEMENT : 

Handling semi -structured logs (n ested JSON inside a CSV column).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling semi -structured logs (n ested JSON inside a CSV column).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end    
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object NestedJSONInCSV {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("NestedJSONInCSV")
      .getOrCreate()

    val jsonSchema = StructType(Seq(
      StructField("event_type", StringType),
      StructField("user_id", StringType),
      StructField("timestamp", StringType),
      StructField("details", StructType(Seq(
        StructField("ip", StringType),
        StructField("location", StringType),
        StructField("response_time", IntegerType)
      )))
    ))

    val df = spark.read
      .option("header", "true")
      .option("multiLine", "true")
      .csv("s3://bucket/semi_structured_logs/")

    val parsedDF = df.withColumn("parsed_log", from_json(col("log"), jsonSchema))

    val flattenedDF = parsedDF.select(
      col("parsed_log.event_type"),
      col("parsed_log.user_id"),
      col("parsed_log.timestamp"),
      col("parsed_log.details.ip"),
      col("parsed_log.details.location"),
      col("parsed_log.details.response_time")
    )

    flattenedDF.write.mode("overwrite").parquet("s3://bucket/output/flattened_logs")

    spark.stop()
  }
}
