PROBLEM STATEMENT : 

Backpressure handling for Kafka ingestion.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Backpressure handling for Kafka ingestion.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object KafkaBackpressureHandling {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("KafkaBackpressureHandling")
      .config("spark.streaming.backpressure.enabled", "true")
      .config("spark.streaming.kafka.maxRatePerPartition", "1000")
      .config("spark.sql.shuffle.partitions", "200")
      .getOrCreate()

    val df = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "broker1:9092")
      .option("subscribe", "events")
      .option("startingOffsets", "latest")
      .option("maxOffsetsPerTrigger", "50000")
      .load()

    val parsedDF = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

    parsedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/kafka_backpressure/")
      .option("checkpointLocation", "s3://bucket/checkpoints/kafka_backpressure/")
      .outputMode("append")
      .start()
      .awaitTermination()

    spark.stop()
  }
}

