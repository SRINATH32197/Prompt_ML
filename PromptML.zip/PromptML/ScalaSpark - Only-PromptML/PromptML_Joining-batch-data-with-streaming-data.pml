PROBLEM STATEMENT : 

Joining batch data with streaming data.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Joining batch data with streaming data.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object JoinBatchWithStreaming {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("JoinBatchWithStreaming")
      .getOrCreate()

    val batchDF = spark.read.parquet("s3://bucket/batch_reference_data/")

    val streamingDF = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "broker1:9092")
      .option("subscribe", "events")
      .option("startingOffsets", "latest")
      .load()

    val parsedStreamingDF = streamingDF.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

    val joinedDF = parsedStreamingDF.join(batchDF, parsedStreamingDF("key") === batchDF("ref_key"), "inner")

    joinedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/joined_stream_batch/")
      .option("checkpointLocation", "s3://bucket/checkpoints/joined_stream_batch/")
      .outputMode("append")
      .start()
      .awaitTermination()

    spark.stop()
  }
}

