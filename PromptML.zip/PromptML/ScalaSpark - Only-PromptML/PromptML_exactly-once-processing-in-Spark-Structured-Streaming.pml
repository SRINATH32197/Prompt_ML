PROBLEM STATEMENT : 

Implementing exactly -once processing in Spark Structured Streaming.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing exactly -once processing in Spark Structured Streaming.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object ExactlyOnceProcessing {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ExactlyOnceProcessing")
      .config("spark.sql.streaming.checkpointLocation", "s3://bucket/checkpoints/exactly_once/")
      .getOrCreate()

    val df = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "broker1:9092,broker2:9092")
      .option("subscribe", "events")
      .option("startingOffsets", "latest")
      .load()

    val parsedDF = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "timestamp")

    parsedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/exactly_once/")
      .option("checkpointLocation", "s3://bucket/checkpoints/exactly_once/")
      .outputMode("append")
      .start()
      .awaitTermination()

    spark.stop()
  }
}

