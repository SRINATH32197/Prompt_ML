PROBLEM STATEMENT : 

Skipping duplicate files in incremental data loads.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Skipping duplicate files in incremental data loads.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions.input_file_name
import scala.collection.JavaConverters._
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.ListObjectsV2Request

object SkipDuplicateFiles {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SkipDuplicateFiles")
      .getOrCreate()

    val processedDF = spark.read.parquet("s3://bucket/processed_metadata/")
    val processedFiles = processedDF.select("file_name").collect().map(_.getString(0)).toSet

    val s3Client = AmazonS3ClientBuilder.defaultClient()
    val bucket = "bucket"
    val prefix = "incremental_data/"
    val request = new ListObjectsV2Request().withBucketName(bucket).withPrefix(prefix)
    val result = s3Client.listObjectsV2(request)

    val newFiles = result.getObjectSummaries.asScala
      .map(_.getKey)
      .map(key => s"s3://$bucket/$key")
      .filterNot(processedFiles.contains)
      .toArray

    if (newFiles.nonEmpty) {
      val df = spark.read.option("header", "true").csv(newFiles: _*)
        .withColumn("file_name", input_file_name())

      df.write.mode("append").parquet("s3://bucket/output/incremental_data")
      df.select("file_name").distinct().write.mode("append").parquet("s3://bucket/processed_metadata/")
    }

    spark.stop()
  }
}
