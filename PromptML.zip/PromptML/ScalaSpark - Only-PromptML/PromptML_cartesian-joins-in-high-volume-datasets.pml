PROBLEM STATEMENT : 

Avoiding cartesian joins in high -volume datasets.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Avoiding cartesian joins in high -volume datasets.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}

object AvoidCartesianJoin {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AvoidCartesianJoin")
      .getOrCreate()

    val dfA = spark.read.parquet("s3://bucket/high_volume_a/")
    val dfB = spark.read.parquet("s3://bucket/high_volume_b/")

    val filteredA = dfA.filter("join_key IS NOT NULL")
    val filteredB = dfB.filter("join_key IS NOT NULL")

    val joinedDF = filteredA.join(filteredB, Seq("join_key"))

    joinedDF.write.mode("overwrite").parquet("s3://bucket/output/avoided_cartesian_join")

    spark.stop()
  }
}
