PROBLEM STATEMENT : 

Merging incremental updates with CDC logic.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Merging incremental updates with CDC logic.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT: 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

object CDCMergeUpdates {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("CDCMergeUpdates")
      .getOrCreate()

    val baseDF = spark.read.parquet("s3://bucket/base_data/")
    val incrementalDF = spark.read.parquet("s3://bucket/incremental_data/")

    val mergedDF = baseDF.unionByName(incrementalDF)

    val windowSpec = Window.partitionBy("id").orderBy(col("update_ts").desc)

    val dedupedDF = mergedDF.withColumn("rn", row_number().over(windowSpec))
      .filter(col("rn") === 1)
      .drop("rn")

    dedupedDF.write.mode("overwrite").parquet("s3://bucket/output/cdc_merged")

    spark.stop()
  }
}
