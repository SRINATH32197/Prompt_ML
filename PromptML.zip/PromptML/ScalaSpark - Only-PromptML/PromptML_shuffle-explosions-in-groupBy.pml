PROBLEM STATEMENT : 

Avoiding shuffle explosions in groupBy operations.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Avoiding shuffle explosions in groupBy operations.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object AvoidShuffleExplosionGroupBy {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AvoidShuffleExplosionGroupBy")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_skewed_data/")

    val saltedDF = df.withColumn("salt", (rand() * 10).cast("int"))

    val groupedDF = saltedDF.groupBy("group_key", "salt").count()

    val finalDF = groupedDF.groupBy("group_key").agg(sum("count").alias("total_count"))

    finalDF.write.mode("overwrite").parquet("s3://bucket/output/groupby_optimized")

    spark.stop()
  }
}
