PROBLEM STATEMENT : 

Masking PII data in Delta tables.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Masking PII data in Delta tables.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object DeltaPIIMasking {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DeltaPIIMasking")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val df = spark.read.format("delta").load("s3://bucket/source_table/")

    val maskedDF = df.withColumn("email", sha2(col("email"), 256))
      .withColumn("phone", lit("XXX-XXX-XXXX"))
      .withColumn("name", concat_ws(" ", lit("User"), sha2(col("name"), 256).substr(1, 6)))

    maskedDF.write.format("delta").mode("overwrite").save("s3://bucket/masked_table/")
  }
}