PROBLEM STATEMENT : 

Applying custom UDFs with heavy computation efficiently.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Applying custom UDFs with heavy computation efficiently.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.types.DoubleType

object EfficientHeavyUDF {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("EfficientHeavyUDF")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/compute_data/")

    val heavyComputationUDF: UserDefinedFunction = udf((x: Double) =>
      math.log(math.sqrt(x * x + 1)) * math.exp(-x / 100)
    )

    val resultDF = df.withColumn("computed_value", heavyComputationUDF(col("input_value")))

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/udf_computed")

    spark.stop()
  }
}
