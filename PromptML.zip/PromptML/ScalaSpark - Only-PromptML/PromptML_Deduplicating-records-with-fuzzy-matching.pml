PROBLEM STATEMENT : 

Deduplicating records with fuzzy matching.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Deduplicating records with fuzzy matching.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT: 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

object FuzzyDeduplication {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("FuzzyDeduplication")
      .getOrCreate()

    val df = spark.read.option("header", "true").csv("s3://bucket/raw_data/")

    val joinedDF = df.alias("a").join(
      df.alias("b"),
      levenshtein(col("a.name"), col("b.name")) <= 2 &&
      col("a.id") < col("b.id"),
      "inner"
    )

    val duplicates = joinedDF.select(col("b.id").alias("duplicate_id"))

    val dedupedDF = df.join(duplicates, df("id") === duplicates("duplicate_id"), "left_anti")

    dedupedDF.write.mode("overwrite").parquet("s3://bucket/output/fuzzy_deduplicated")

    spark.stop()
  }
}
