PROBLEM STATEMENT : 

Exploding and re -nesting deeply nested JSON.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Exploding and re -nesting deeply nested JSON.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object ExplodeReNestJSON {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ExplodeReNestJSON")
      .getOrCreate()

    val df = spark.read.option("multiLine", "true").json("s3://bucket/nested_data.json")

    val explodedDF = df.withColumn("item", explode(col("user.details.items")))

    val flatDF = explodedDF.select(
      col("user.id").alias("user_id"),
      col("user.name").alias("user_name"),
      col("item.type").alias("item_type"),
      col("item.value").alias("item_value")
    )

    val nestedDF = flatDF.groupBy("user_id", "user_name")
      .agg(collect_list(struct("item_type", "item_value")).alias("items"))

    val finalDF = nestedDF.select(
      struct(
        col("user_id").alias("id"),
        col("user_name").alias("name"),
        col("items")
      ).alias("user")
    )

    finalDF.write.mode("overwrite").json("s3://bucket/output/renested_json")

    spark.stop()
  }
}
