PROBLEM STATEMENT : 

Splitting a single column into multiple n ormalized tables.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Splitting a single column into multiple n ormalized tables.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT:

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object ColumnSplitNormalization {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ColumnSplitNormalization")
      .getOrCreate()

    val df = spark.read.option("header", "true").csv("s3://bucket/raw_data/")

    val splitDF = df.withColumn("parts", split(col("composite_column"), ":"))

    val tableA = splitDF.select(col("id"), col("parts").getItem(0).alias("type"))
    val tableB = splitDF.select(col("id"), col("parts").getItem(1).alias("value"))
    val tableC = splitDF.select(col("id"), col("parts").getItem(2).alias("source"))

    tableA.write.mode("overwrite").parquet("s3://bucket/output/table_a")
    tableB.write.mode("overwrite").parquet("s3://bucket/output/table_b")
    tableC.write.mode("overwrite").parquet("s3://bucket/output/table_c")

    spark.stop()
  }
}

