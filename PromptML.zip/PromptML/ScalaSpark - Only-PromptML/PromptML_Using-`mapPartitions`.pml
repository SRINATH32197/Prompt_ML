PROBLEM STATEMENT : 

Using `mapPartitions` instead of `map` for efficiency.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Using `mapPartitions` instead of `map` for efficiency.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, Row}
import org.apache.spark.sql.types._

object MapPartitionsEfficiency {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("MapPartitionsEfficiency")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_dataset/")

    val rdd = df.select("id", "value").rdd.mapPartitions { iter =>
      iter.map { row =>
        val id = row.getAs[String]("id")
        val value = row.getAs[Int]("value") * 2
        Row(id, value)
      }
    }

    val schema = StructType(Seq(
      StructField("id", StringType, nullable = true),
      StructField("processed_value", IntegerType, nullable = true)
    ))

    val resultDF = spark.createDataFrame(rdd, schema)

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/mappartitions_result")

    spark.stop()
  }
}

