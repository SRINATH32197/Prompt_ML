PROBLEM STATEMENT : 

Handling straggler tasks in streaming jobs.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling straggler tasks in streaming jobs.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession

object StreamingStragglerMitigation {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("StreamingStragglerMitigation")
      .config("spark.sql.shuffle.partitions", "800")
      .config("spark.sql.adaptive.enabled", "true")
      .config("spark.sql.adaptive.skewJoin.enabled", "true")
      .config("spark.sql.adaptive.advisoryPartitionSizeInBytes", "64MB")
      .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
      .config("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider")
      .getOrCreate()

    val streamDF = spark.readStream
      .format("json")
      .option("maxFilesPerTrigger", 100)
      .load("s3://bucket/streaming_input/")

    streamDF.writeStream
      .format("delta")
      .outputMode("append")
      .option("checkpointLocation", "s3://bucket/checkpoints/straggler_mitigation/")
      .start("s3://bucket/delta_output/")
      .awaitTermination()
  }
}

