PROBLEM STATEMENT : 

Optimizing union of 100+ DataFrames without OOM errors.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Optimizing union of 100+ DataFrames without OOM errors.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import scala.collection.mutable.ListBuffer

object OptimizedUnion100DFs {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("OptimizedUnion100DFs")
      .getOrCreate()

    val paths = (0 until 100).map(i => s"s3://bucket/data/part_$i/")
    val dfs = ListBuffer[DataFrame]()

    paths.foreach { path =>
      val df = spark.read.parquet(path).persist()
      dfs += df
    }

    val unionDF = dfs.reduce((df1, df2) => df1.unionByName(df2))

    unionDF.write.mode("overwrite").parquet("s3://bucket/output/union_100_dfs")

    spark.stop()
  }
}
