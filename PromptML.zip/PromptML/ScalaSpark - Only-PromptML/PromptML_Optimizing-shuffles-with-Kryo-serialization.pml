PROBLEM STATEMENT : 

Optimizing shuffles with Kryo serialization.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Optimizing shuffles with Kryo serialization.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}

object OptimizeShuffleWithKryo {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("OptimizeShuffleWithKryo")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.kryo.registrationRequired", "false")
      .config("spark.sql.shuffle.partitions", "200")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_shuffle_data/")

    val resultDF = df.groupBy("category")
      .agg(Map("value" -> "sum", "id" -> "count"))

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/kryo_optimized_shuffle")

    spark.stop()
  }
}
