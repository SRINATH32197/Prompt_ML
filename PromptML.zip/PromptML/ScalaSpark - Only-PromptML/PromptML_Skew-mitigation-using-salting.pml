PROBLEM STATEMENT : 

Skew mitigation using salting.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Skew mitigation using salting.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object SkewMitigationSalting {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SkewMitigationSalting")
      .getOrCreate()

    val skewedDF = spark.read.parquet("s3://bucket/skewed_dataset/")
    val smallDF = spark.read.parquet("s3://bucket/small_dataset/")

    val saltedSkewed = skewedDF.withColumn("salt", (rand() * 10).cast("int"))
    val saltedSmall = smallDF.crossJoin(spark.range(0, 10).toDF("salt"))

    val resultDF = saltedSkewed.join(saltedSmall, Seq("join_key", "salt"), "inner")

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/salted_join_result")

    spark.stop()
  }
}
