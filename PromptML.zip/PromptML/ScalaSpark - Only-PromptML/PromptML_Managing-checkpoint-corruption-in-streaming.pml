PROBLEM STATEMENT : 

Managing checkpoint corruption in streaming.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Managing checkpoint corruption in streaming.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end  
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession
import java.nio.file.{Files, Paths}
import scala.util.Try

object StreamingCheckpointRecovery {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("StreamingCheckpointRecovery")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val checkpointPath = "s3://bucket/checkpoints/stream_job/"
    val outputPath = "s3://bucket/delta_output/"

    val streamDF = spark.readStream
      .format("json")
      .option("maxFilesPerTrigger", 10)
      .load("s3://bucket/streaming_input/")

    Try {
      streamDF.writeStream
        .format("delta")
        .outputMode("append")
        .option("checkpointLocation", checkpointPath)
        .start(outputPath)
        .awaitTermination()
    }.recover {
      case _: Throwable =>
        import sys.process._
        s"aws s3 rm $checkpointPath --recursive".!
        streamDF.writeStream
          .format("delta")
          .outputMode("append")
          .option("checkpointLocation", checkpointPath)
          .start(outputPath)
          .awaitTermination()
    }
  }
}
