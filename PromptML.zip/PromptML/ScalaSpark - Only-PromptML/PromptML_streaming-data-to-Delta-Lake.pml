PROBLEM STATEMENT : 

Writing streaming data to Delta Lake with schema enforcement.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Writing streaming data to Delta Lake with schema enforcement.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._

object StreamingToDeltaWithSchemaEnforcement {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("StreamingToDeltaWithSchemaEnforcement")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.streaming.schemaInference", "false")
      .getOrCreate()

    val schema = StructType(Seq(
      StructField("id", StringType, nullable = false),
      StructField("value", IntegerType, nullable = false),
      StructField("timestamp", TimestampType, nullable = false)
    ))

    val streamDF = spark.readStream
      .format("json")
      .schema(schema)
      .load("s3://bucket/streaming_input/")

    streamDF.writeStream
      .format("delta")
      .outputMode("append")
      .option("checkpointLocation", "s3://bucket/checkpoints/stream_to_delta/")
      .option("mergeSchema", "false")
      .start("s3://bucket/delta_output/")
      .awaitTermination()
  }
}
```