PROBLEM STATEMENT : 

Implementing recursive joins (hierarchical org structures).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing recursive joins (hierarchical org structures).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object RecursiveJoinOrgHierarchy {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("RecursiveJoinOrgHierarchy")
      .getOrCreate()

    val orgDF = spark.read.parquet("s3://bucket/org_structure/")

    var hierarchyDF = orgDF.filter("manager_id IS NULL")
      .selectExpr("employee_id as root_id", "employee_id", "manager_id", "1 as level")

    for (i <- 1 to 9) {
      val nextLevel = hierarchyDF.alias("h").join(
        orgDF.alias("o"),
        col("h.employee_id") === col("o.manager_id"),
        "inner"
      ).selectExpr(
        "h.root_id",
        "o.employee_id",
        "o.manager_id",
        s"${i + 1} as level"
      )

      hierarchyDF = hierarchyDF.union(nextLevel)
    }

    hierarchyDF.write.mode("overwrite").parquet("s3://bucket/output/org_hierarchy")

    spark.stop()
  }
}
