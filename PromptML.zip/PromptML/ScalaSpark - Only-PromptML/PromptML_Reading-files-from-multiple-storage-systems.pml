PROBLEM STATEMENT : 

Reading files from multiple storage systems (S3, HDFS, ADLS) in one job.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Readi ng files from multiple storage systems (S3, HDFS, ADLS) in one job.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object MultiStorageRead {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("MultiStorageRead")
      .getOrCreate()

    val s3DF = spark.read.parquet("s3a://bucket/s3_data/")
    val hdfsDF = spark.read.parquet("hdfs://namenode:8020/user/hdfs/hdfs_data/")
    val adlsDF = spark.read.parquet("abfss://container@account.dfs.core.windows.net/adls_data/")

    val combinedDF = s3DF.unionByName(hdfsDF, true).unionByName(adlsDF, true)

    combinedDF.write.mode("overwrite").parquet("s3a://bucket/output/combined_data")

    spark.stop()
  }
}
