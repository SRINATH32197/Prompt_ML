PROBLEM STATEMENT : 

Building SCD Type 2 in Delta Lake.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Building SCD Type 2 in Delta Lake.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.SparkSession
import io.delta.tables._
import org.apache.spark.sql.functions._

object SCDType2DeltaLake {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SCDType2DeltaLake")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    val incomingDF = spark.read.format("json").load("s3://bucket/incoming_data/")
      .withColumn("start_date", current_timestamp())
      .withColumn("end_date", lit(null).cast("timestamp"))
      .withColumn("is_current", lit(true))

    val targetTable = DeltaTable.forPath(spark, "s3://bucket/delta_scd2_table/")

    targetTable.as("target")
      .merge(
        incomingDF.as("source"),
        "target.id = source.id AND target.is_current = true AND (target.name <> source.name OR target.value <> source.value)"
      )
      .whenMatched()
      .updateExpr(Map(
        "end_date" -> "current_timestamp()",
        "is_current" -> "false"
      ))
      .whenNotMatched()
      .insertExpr(Map(
        "id" -> "source.id",
        "name" -> "source.name",
        "value" -> "source.value",
        "start_date" -> "source.start_date",
        "end_date" -> "source.end_date",
        "is_current" -> "source.is_current"
      ))
      .execute()
  }
}
