PROBLEM STATEMENT : 

Avoiding repeated computation with checkpointing.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Avoiding repeated computation with checkpointing.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object AvoidRepeatedComputationCheckpoint {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AvoidRepeatedComputationCheckpoint")
      .getOrCreate()

    spark.sparkContext.setCheckpointDir("s3://bucket/checkpoints/")

    val df = spark.read.parquet("s3://bucket/complex_transform_input/")
    val transformedDF = df.filter("value > 100").groupBy("category").count()

    val checkpointedDF = transformedDF.checkpoint(true)

    val finalDF = checkpointedDF.filter("count > 1000")

    finalDF.write.mode("overwrite").parquet("s3://bucket/output/checkpointed_result")

    spark.stop()
  }
}

