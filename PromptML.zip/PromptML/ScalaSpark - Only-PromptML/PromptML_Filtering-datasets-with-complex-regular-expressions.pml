PROBLEM STATEMENT : 

Filtering datasets with complex regular expressions.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Filtering datasets with complex regular expressions.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :


import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object RegexFiltering {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("RegexFiltering")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/text_data/")

    val filteredDF = df.filter(
      col("text_column").rlike("(?i)\\b(?:error|fail(?:ure)?|exception)\\b.*\\d{3}")
    )

    filteredDF.write.mode("overwrite").parquet("s3://bucket/output/regex_filtered")

    spark.stop()
  }
}
