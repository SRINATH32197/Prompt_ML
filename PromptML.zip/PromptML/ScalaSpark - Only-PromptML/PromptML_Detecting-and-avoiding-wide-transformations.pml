PROBLEM STATEMENT : 

Detecting and avoiding wide transformations.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Detecting and avoiding wide transformations.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, Row}
import org.apache.spark.sql.types._

object AvoidWideTransformations {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("AvoidWideTransformations")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_dataset/")

    val rdd = df.select("key", "value").rdd.mapPartitions { iter =>
      iter.map { row =>
        val key = row.getAs[String]("key")
        val value = row.getAs[Double]("value") * 2
        Row(key, value)
      }
    }

    val schema = StructType(Seq(
      StructField("key", StringType, nullable = true),
      StructField("processed_value", DoubleType, nullable = true)
    ))

    val resultDF = spark.createDataFrame(rdd, schema)

    resultDF.write.mode("overwrite").parquet("s3://bucket/output/avoided_wide_transformation")

    spark.stop()
  }
}
