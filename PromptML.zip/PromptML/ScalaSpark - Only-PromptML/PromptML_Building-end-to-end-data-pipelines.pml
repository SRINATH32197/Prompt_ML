PROBLEM STATEMENT : 

Building end -to-end data pipelines with batch + streaming on Delta.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Building end -to-end data pipelines with batch + streaming on Delta.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object DeltaBatchStreamingPipeline {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DeltaBatchStreamingPipeline")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    // Batch ingestion
    val batchDF = spark.read.format("json").load("s3://bucket/batch_data/")
    batchDF.write.format("delta").mode("append").save("s3://bucket/bronze/")

    // Streaming ingestion
    val streamDF = spark.readStream.format("json").load("s3://bucket/streaming_data/")
    streamDF.writeStream
      .format("delta")
      .outputMode("append")
      .option("checkpointLocation", "s3://bucket/checkpoints/bronze/")
      .start("s3://bucket/bronze/")

    // Silver transformation
    val silverDF = spark.readStream.format("delta").load("s3://bucket/bronze/")
      .filter("status = 'active'")
      .withColumn("event_ts", expr("cast(timestamp as timestamp)"))

    silverDF.writeStream
      .format("delta")
      .outputMode("append")
      .option("checkpointLocation", "s3://bucket/checkpoints/silver/")
      .start("s3://bucket/silver/")

    // Gold aggregation
    val goldDF = spark.readStream.format("delta").load("s3://bucket/silver/")
      .groupBy("region")
      .agg(expr("count(*) as active_count"))

    goldDF.writeStream
      .format("delta")
      .outputMode("complete")
      .option("checkpointLocation", "s3://bucket/checkpoints/gold/")
      .start("s3://bucket/gold/")
  }
}
