PROBLEM STATEMENT : 

Reading ZIP archives without fully ex tracting them.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Reading ZIP archives without fully ex tracting them.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import java.io.InputStream
import java.util.zip.ZipInputStream
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.GetObjectRequest
import org.apache.commons.io.IOUtils

object ReadZipWithoutExtract {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ReadZipWithoutExtract")
      .getOrCreate()

    val s3Client = AmazonS3ClientBuilder.defaultClient()
    val bucket = "bucket"
    val key = "archives/data.zip"
    val s3Object = s3Client.getObject(new GetObjectRequest(bucket, key))
    val zipStream = new ZipInputStream(s3Object.getObjectContent)

    Stream.continually(zipStream.getNextEntry)
      .takeWhile(_ != null)
      .filter(entry => entry.getName.endsWith(".csv"))
      .foreach { entry =>
        val bytes = IOUtils.toByteArray(zipStream)
        val rdd = spark.sparkContext.parallelize(Seq(new String(bytes)))
        val df = spark.read.option("header", "true").csv(rdd)
        df.write.mode("append").parquet("s3://bucket/output/unzipped_data")
      }

    zipStream.close()
    spark.stop()
  }
}
