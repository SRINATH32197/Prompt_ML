PROBLEM STATEMENT : 

Building data lakehouse medallion architecture.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Building data lakehouse medallion architecture.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object LakehouseMedallionArchitecture {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("LakehouseMedallionArchitecture")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    // Bronze Layer: Raw ingestion
    val bronzeDF = spark.read.format("json").load("s3://bucket/raw_data/")
    bronzeDF.write.format("delta").mode("overwrite").save("s3://bucket/bronze/")

    // Silver Layer: Cleansed and filtered
    val silverDF = spark.read.format("delta").load("s3://bucket/bronze/")
      .filter("status = 'active'")
      .withColumn("event_ts", col("timestamp").cast("timestamp"))
    silverDF.write.format("delta").mode("overwrite").save("s3://bucket/silver/")

    // Gold Layer: Aggregated and business-ready
    val goldDF = spark.read.format("delta").load("s3://bucket/silver/")
      .groupBy("region")
      .agg(expr("count(*) as active_count"))
    goldDF.write.format("delta").mode("overwrite").save("s3://bucket/gold/")
  }
}

