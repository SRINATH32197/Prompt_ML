PROBLEM STATEMENT : 

Handling mixed encodings (UTF -8, ISO -8859 -1).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling mixed encodings (UTF -8, ISO -8859 -1).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import scala.collection.JavaConverters._
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.GetObjectRequest
import org.apache.commons.io.IOUtils
import org.mozilla.universalchardet.UniversalDetector

object MixedEncodingHandler {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("MixedEncodingHandler")
      .getOrCreate()

    val s3Client = AmazonS3ClientBuilder.defaultClient()
    val bucket = "bucket"
    val prefix = "mixed_encoding/"
    val objects = s3Client.listObjectsV2(bucket, prefix).getObjectSummaries.asScala

    def detectEncoding(key: String): String = {
      val obj = s3Client.getObject(new GetObjectRequest(bucket, key))
      val stream = obj.getObjectContent
      val bytes = IOUtils.toByteArray(stream)
      val detector = new UniversalDetector(null)
      detector.handleData(bytes, 0, math.min(bytes.length, 1000))
      detector.dataEnd()
      val encoding = detector.getDetectedCharset
      detector.reset()
      stream.close()
      encoding
    }

    objects.foreach { obj =>
      val key = obj.getKey
      val encoding = detectEncoding(key)
      val path = s"s3://$bucket/$key"
      val df = spark.read.option("header", "true").option("encoding", encoding).csv(path)
      df.write.mode("append").parquet("s3://bucket/output/normalized_encoding")
    }

    spark.stop()
  }
}
