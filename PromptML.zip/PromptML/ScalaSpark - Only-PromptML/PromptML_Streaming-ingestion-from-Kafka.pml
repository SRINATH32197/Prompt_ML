PROBLEM STATEMENT : 

Streaming ingestion from Kafka with schema changes.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Streaming ingestion from Kafka with schema changes.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object KafkaSchemaEvolution {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("KafkaSchemaEvolution")
      .getOrCreate()

    val schemaV1 = StructType(Seq(
      StructField("id", StringType),
      StructField("name", StringType)
    ))

    val schemaV2 = schemaV1.add("email", StringType)

    val kafkaDF = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "kafka:9092")
      .option("subscribe", "user_topic")
      .option("startingOffsets", "latest")
      .load()

    val parsedDF = kafkaDF.selectExpr("CAST(value AS STRING)")
      .withColumn("json", from_json(col("value"), schemaV2))
      .select("json.*")

    parsedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/kafka_stream")
      .option("checkpointLocation", "s3://bucket/checkpoints/kafka_stream")
      .outputMode("append")
      .start()
      .awaitTermination()
  }
}
