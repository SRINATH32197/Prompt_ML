PROBLEM STATEMENT : 

Monitoring and alerting for streaming lag.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Monitoring and al erting for streaming lag.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object StreamingLagMonitoring {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("StreamingLagMonitoring")
      .config("spark.sql.streaming.metricsEnabled", "true")
      .getOrCreate()

    val streamDF = spark.readStream
      .format("json")
      .option("maxFilesPerTrigger", 100)
      .load("s3://bucket/streaming_input/")
      .withColumn("event_ts", col("timestamp").cast("timestamp"))
      .withColumn("ingest_ts", expr("current_timestamp()"))
      .withColumn("lag_seconds", expr("unix_timestamp(ingest_ts) - unix_timestamp(event_ts)"))

    val lagDF = streamDF.select("id", "event_ts", "ingest_ts", "lag_seconds")
      .filter("lag_seconds > 300")

    lagDF.writeStream
      .format("console")
      .outputMode("append")
      .option("truncate", "false")
      .start()
      .awaitTermination()
  }
}

