PROBLEM STATEMENT : 

Streaming aggregation with millions of keys.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Streaming aggregation with millions of keys.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object StreamingAggregationMillionsOfKeys {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("StreamingAggregationMillionsOfKeys")
      .config("spark.sql.shuffle.partitions", "800")
      .config("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider")
      .getOrCreate()

    val streamDF = spark.readStream
      .format("json")
      .option("maxFilesPerTrigger", 100)
      .load("s3://bucket/streaming_input/")
      .withColumn("event_ts", col("timestamp").cast("timestamp"))

    val aggregatedDF = streamDF
      .withWatermark("event_ts", "10 minutes")
      .groupBy(
        window(col("event_ts"), "5 minutes", "1 minute"),
        col("key")
      ).count()

    aggregatedDF.writeStream
      .format("delta")
      .outputMode("update")
      .option("checkpointLocation", "s3://bucket/checkpoints/agg_millions_keys/")
      .start("s3://bucket/delta_output/")
      .awaitTermination()
  }
}

