PROBLEM STATEMENT : 

Handling schema drift in s treaming JSON payloads.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling schema drift in s treaming JSON payloads.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession

object SchemaDriftStreamingJSON {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SchemaDriftStreamingJSON")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .config("spark.sql.streaming.schemaInference", "true")
      .config("spark.databricks.delta.schema.autoMerge.enabled", "true")
      .getOrCreate()

    val streamDF = spark.readStream
      .format("json")
      .option("multiLine", "true")
      .load("s3://bucket/streaming_json_input/")

    streamDF.writeStream
      .format("delta")
      .outputMode("append")
      .option("checkpointLocation", "s3://bucket/checkpoints/schema_drift/")
      .option("mergeSchema", "true")
      .start("s3://bucket/delta_output/")
      .awaitTermination()
  }
}