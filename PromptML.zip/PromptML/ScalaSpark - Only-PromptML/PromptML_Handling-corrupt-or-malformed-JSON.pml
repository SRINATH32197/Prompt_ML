PROBLEM STATEMENT : 

Handling corrupt or malformed JSON records during ingestion.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling corrupt or malformed JSON records during ingestion.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object HandleMalformedJSON {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("HandleMalformedJSON")
      .getOrCreate()

    val df = spark.read
      .option("mode", "PERMISSIVE")
      .option("columnNameOfCorruptRecord", "_corrupt_record")
      .json("s3://bucket/json_data/")

    val validDF = df.filter("_corrupt_record IS NULL")
    val corruptDF = df.filter("_corrupt_record IS NOT NULL")

    validDF.write.mode("overwrite").parquet("s3://bucket/output/valid_json")
    corruptDF.write.mode("overwrite").parquet("s3://bucket/output/corrupt_json")

    spark.stop()
  }
}
