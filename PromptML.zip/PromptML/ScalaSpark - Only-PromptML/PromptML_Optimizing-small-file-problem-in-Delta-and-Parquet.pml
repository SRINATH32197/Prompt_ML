PROBLEM STATEMENT : 

Optimizing small file problem in Delta/Parquet.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Optimizing small file problem in Delta/Parquet.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}

object OptimizeSmallFiles {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("OptimizeSmallFiles")
      .getOrCreate()

    val df = spark.read.format("delta").load("s3://bucket/delta_table/")

    val optimizedDF = df.coalesce(10)

    optimizedDF.write.format("delta")
      .mode("overwrite")
      .option("dataChange", "false")
      .save("s3://bucket/delta_table_optimized")

    spark.stop()
  }
}
