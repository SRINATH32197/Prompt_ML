PROBLEM STATEMENT : 

Managing late data with watermarks.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Managing late data with watermarks.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object WatermarkLateData {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("WatermarkLateData")
      .getOrCreate()

    val df = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "broker1:9092")
      .option("subscribe", "events")
      .option("startingOffsets", "latest")
      .load()

    val parsedDF = df.selectExpr("CAST(value AS STRING)", "timestamp")
      .withWatermark("timestamp", "10 minutes")
      .groupBy(window(col("timestamp"), "5 minutes"))
      .count()

    parsedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/watermark_late_data/")
      .option("checkpointLocation", "s3://bucket/checkpoints/watermark_late_data/")
      .outputMode("append")
      .start()
      .awaitTermination()

    spark.stop()
  }
}

