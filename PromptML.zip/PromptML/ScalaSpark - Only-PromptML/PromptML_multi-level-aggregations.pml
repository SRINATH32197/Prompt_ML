PROBLEM STATEMENT : 

Implementing multi -level aggregations (rollup/cube).


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing multi -level aggregations (rollup/cube).
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object MultiLevelAggregation {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("MultiLevelAggregation")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/sales_data/")

    val rollupDF = df.rollup("region", "product")
      .agg(sum("sales").alias("total_sales"))

    rollupDF.write.mode("overwrite").parquet("s3://bucket/output/rollup_sales")

    val cubeDF = df.cube("region", "product")
      .agg(sum("sales").alias("total_sales"))

    cubeDF.write.mode("overwrite").parquet("s3://bucket/output/cube_sales")

    spark.stop()
  }
}
