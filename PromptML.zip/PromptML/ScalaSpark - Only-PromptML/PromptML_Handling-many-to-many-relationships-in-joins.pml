PROBLEM STATEMENT : 

Handling many -to-many relationships in joins.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling many -to-many relationships in joins.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object ManyToManyJoin {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ManyToManyJoin")
      .getOrCreate()

    val ordersDF = spark.read.parquet("s3://bucket/orders/")
    val productsDF = spark.read.parquet("s3://bucket/products/")
    val orderProductMapDF = spark.read.parquet("s3://bucket/order_product_map/")

    val ordersMappedDF = ordersDF.join(orderProductMapDF, Seq("order_id"))
    val finalDF = ordersMappedDF.join(productsDF, Seq("product_id"))

    finalDF.write.mode("overwrite").parquet("s3://bucket/output/many_to_many_joined")

    spark.stop()
  }
}
