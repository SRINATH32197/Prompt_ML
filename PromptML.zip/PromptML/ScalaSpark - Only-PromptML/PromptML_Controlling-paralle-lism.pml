PROBLEM STATEMENT : 

Controlling paralle lism with `repartition` vs. `coalesce`.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Controlling paralle lism with `repartition` vs. `coalesce`.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}

object ControlParallelism {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ControlParallelism")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/large_dataset/")

    val repartitionedDF = df.repartition(200)
    val coalescedDF = repartitionedDF.coalesce(20)

    coalescedDF.write.mode("overwrite").parquet("s3://bucket/output/controlled_parallelism")

    spark.stop()
  }
}

