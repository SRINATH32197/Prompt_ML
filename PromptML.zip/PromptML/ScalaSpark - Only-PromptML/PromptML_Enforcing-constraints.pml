PROBLEM STATEMENT : 

Enforcing constraints (unique, not null) in D elta.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Enforcing constraints (unique, not null) in D elta.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.SparkSession

object DeltaConstraintsEnforcement {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("DeltaConstraintsEnforcement")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      .getOrCreate()

    spark.sql("""
      CREATE TABLE delta.`s3://bucket/delta_table/` (
          id STRING NOT NULL,
          name STRING,
          value INT,
          CONSTRAINT id_unique_constraint UNIQUE (id)
      ) USING DELTA
    """)
  }
}
