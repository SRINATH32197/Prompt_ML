PROBLEM STATEMENT : 

Implementing custom partitioning strategies.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Implementing custom partitioning strategies.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, Row}
import org.apache.spark.sql.types._
import org.apache.spark.rdd.RDD
import org.apache.spark.Partitioner

object CustomPartitioningStrategy {
  class CustomPartitioner(partitions: Int) extends Partitioner {
    override def numPartitions: Int = partitions
    override def getPartition(key: Any): Int = key.hashCode % partitions
  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("CustomPartitioningStrategy")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/partition_input/")
    val rdd = df.select("key", "value").rdd.map {
      case Row(key: String, value: Int) => (key, value)
    }

    val partitionedRDD = rdd.partitionBy(new CustomPartitioner(50))

    val rowRDD = partitionedRDD.map { case (key, value) => Row(key, value) }

    val schema = StructType(Seq(
      StructField("key", StringType, nullable = true),
      StructField("value", IntegerType, nullable = true)
    ))

    val partitionedDF = spark.createDataFrame(rowRDD, schema)

    partitionedDF.write.mode("overwrite").parquet("s3://bucket/output/custom_partitioned")

    spark.stop()
  }
}

