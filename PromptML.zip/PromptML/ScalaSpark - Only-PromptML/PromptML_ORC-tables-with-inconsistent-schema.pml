PROBLEM STATEMENT : 

Loading ORC tables with inconsistent schema evolution.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Loading ORC tables with inconsistent schema evolution.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT:

import org.apache.spark.sql.{SparkSession, DataFrame}

object ORCSchemaEvolution {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ORCSchemaEvolution")
      .getOrCreate()

    val dfV1 = spark.read
      .option("mergeSchema", "true")
      .orc("s3://bucket/orc_data/v1/")

    val dfV2 = spark.read
      .option("mergeSchema", "true")
      .orc("s3://bucket/orc_data/v2/")

    val mergedDF = dfV1.unionByName(dfV2, true)

    mergedDF.write
      .mode("overwrite")
      .option("mergeSchema", "true")
      .orc("s3://bucket/output/merged_orc")

    spark.stop()
  }
}

