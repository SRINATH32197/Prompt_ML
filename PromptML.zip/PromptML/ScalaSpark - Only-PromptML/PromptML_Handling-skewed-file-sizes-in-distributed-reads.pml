PROBLEM STATEMENT : 

Handling skewed file sizes in distributed reads.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Handling skewed file sizes in distributed reads.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions.input_file_name

object SkewedFileSizeRead {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SkewedFileSizeRead")
      .getOrCreate()

    val df = spark.read
      .option("header", "true")
      .csv("s3://bucket/skewed_files/")
      .withColumn("source_file", input_file_name())

    val balancedDF = df.repartition(col("source_file"))

    balancedDF.write.mode("overwrite").parquet("s3://bucket/output/balanced_read")

    spark.stop()
  }
}
