PROBLEM STATEMENT : 

Reading multi -gigabyte CSV files with inconsistent delimiters.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Reading multi -gigabyte CSV files with inconsistent delimiters.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions.input_file_name

object InconsistentDelimiterCSVReader {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("InconsistentDelimiterCSVReader")
      .getOrCreate()

    val delimiters = Seq(",", ";", "\t", "|")

    def readWithDelimiter(delim: String): DataFrame = {
      spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .option("delimiter", delim)
        .csv("s3://bucket/multi_gb_csvs/*.csv")
        .withColumn("source_file", input_file_name())
    }

    val dfs = delimiters.map(readWithDelimiter)
    val combinedDF = dfs.reduce((df1, df2) => df1.unionByName(df2, true))

    combinedDF.write.mode("overwrite").parquet("s3://bucket/output/normalized_csv_data")
    spark.stop()
  }
}
