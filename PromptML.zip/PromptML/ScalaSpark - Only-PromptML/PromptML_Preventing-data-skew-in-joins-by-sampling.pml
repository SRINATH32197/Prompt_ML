PROBLEM STATEMENT : 

Preventing data skew in joins by sampling.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Preventing data skew in joins by sampling.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT :

import org.apache.spark.sql.{SparkSession, DataFrame}

object SkewJoinSampling {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("SkewJoinSampling")
      .getOrCreate()

    val largeDF = spark.read.parquet("s3://bucket/large_dataset/")
    val smallDF = spark.read.parquet("s3://bucket/small_dataset/")

    val sampledSmallDF = smallDF.sample(false, 0.1)

    val joinedDF = largeDF.join(sampledSmallDF, Seq("join_key"), "inner")

    joinedDF.write.mode("overwrite").parquet("s3://bucket/output/skew_sampling_join")

    spark.stop()
  }
}

