PROBLEM STATEMENT : 

Caching vs. persisting with proper storage levels.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Caching vs. persisting with proper storage levels.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT: 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.storage.StorageLevel

object CachingVsPersisting {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("CachingVsPersisting")
      .getOrCreate()

    val df = spark.read.parquet("s3://bucket/compute_heavy_data/")

    val cachedDF = df.cache()
    val persistedDF = df.persist(StorageLevel.MEMORY_AND_DISK)

    cachedDF.count()
    persistedDF.groupBy("category").count().show()

    cachedDF.unpersist()
    persistedDF.unpersist()

    spark.stop()
  }
}
