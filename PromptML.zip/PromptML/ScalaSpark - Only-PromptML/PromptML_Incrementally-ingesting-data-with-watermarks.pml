PROBLEM STATEMENT : 

Incrementally ingesting data with watermarks.


......................................................................................................................................................


PROMPT ML : 

@prompt
    @context
        You are a highly skilled Spark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized Spark code in both PySpark (Python) and Scala Spark.
    @end

    @objective
        Generate Spark code to efficiently solve the following problem statement:
        Incrementally ingesting data with watermarks.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end 
        @end
    @end

    @constraints
        @output_format
            Types: [PySpark, ScalaSpark]
            Languages: [Python, Scala]
        @end
        @rules
            - Always generate PySpark code first, then Scala Spark code
            - Optimize for large-scale datasets
            - Output only Spark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


......................................................................................................................................................


COPILOT OUTPUT : 

import org.apache.spark.sql.{SparkSession, DataFrame}
import org.apache.spark.sql.functions._

object IncrementalIngestionWithWatermark {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("IncrementalIngestionWithWatermark")
      .getOrCreate()

    val df = spark.readStream
      .format("parquet")
      .option("path", "s3://bucket/incoming_data/")
      .option("maxFilesPerTrigger", 1)
      .load()

    val watermarkedDF = df.withWatermark("event_time", "10 minutes")

    val aggregatedDF = watermarkedDF.groupBy("user_id")
      .agg(expr("max(event_time) as latest_event"))

    aggregatedDF.writeStream
      .format("parquet")
      .option("path", "s3://bucket/output/incremental_watermarked")
      .option("checkpointLocation", "s3://bucket/checkpoints/incremental_watermarked")
      .outputMode("append")
      .start()
      .awaitTermination()
  }
}

