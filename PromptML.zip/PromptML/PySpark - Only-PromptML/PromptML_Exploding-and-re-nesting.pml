

@prompt
    @context
        You are a highly skilled PySpark data engineer. 
        You specialize in solving large-scale data problems efficiently 
        by writing optimized PySpark code that runs in distributed environments.
    @end

    @objective
        Generate PySpark code to efficiently solve the following problem statement:
        Exploding and re -nesting deeply nested JSON.
    @end

    @examples
        @example
            @input
                Handle skewed join between large and small datasets
            @end
        @end
    @end
    @constraints
        @output_format
            Type: PySpark Code
            Language: Python
        @end
        @rules
            - Automatically handle the core challenges of the problem
            - Optimize for large-scale datasets
            - Output only PySpark code without extra explanation
            - Code must run in Spark environment
        @end
    @end

    @category
        Data Engineering
    @end
@end


.........................................................................................................................................................................


COPILOT OUTPUT : 

from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, struct, collect_list, col

spark = SparkSession.builder.appName("ExplodeReNestJSON").getOrCreate()

# Load deeply nested JSON
df = spark.read.option("multiLine", "true").json("s3://bucket/nested.json")

# Explode nested arrays
exploded_df = df.withColumn("item", explode(col("order.items"))) \
    .select(
        col("order.order_id").alias("order_id"),
        col("order.customer").alias("customer"),
        col("item.product_id").alias("product_id"),
        col("item.quantity").alias("quantity")
    )

# Apply transformations (example: filter or enrich)
transformed_df = exploded_df.filter(col("quantity") > 0)

# Re-nest into original structure
nested_df = transformed_df.groupBy("order_id", "customer") \
    .agg(collect_list(struct("product_id", "quantity")).alias("items")) \
    .select(struct("order_id", "customer", "items").alias("order"))

# Write output
nested_df.write.mode("overwrite").json("s3://bucket/renested_output/")
