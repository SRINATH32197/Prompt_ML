import os
import pandas as pd
import textwrap
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from PyPDF2 import PdfReader

# --------------------------
# Config
# --------------------------
INPUT_CSV = "problems.csv"                     # your CSV file path
OUTPUT_DIR = "promptml_output"
PDF_FILE = os.path.join(OUTPUT_DIR, "all_prompts.pdf")
TXT_DIR = os.path.join(OUTPUT_DIR, "txt_files")

PROBLEM_COL_CANDIDATES = ["problem", "problem_statement", "prompt", "description", "text"]
MAX_LINE_CHARS = 100
PAGE_MARGIN = 50
FONT = "Helvetica"
FONT_SIZE = 11

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(TXT_DIR, exist_ok=True)

# --------------------------
# Step 1: Load CSV
# --------------------------
df = pd.read_csv(INPUT_CSV, encoding="utf-8", on_bad_lines="skip")

# Detect problem column
problem_col = None
for c in df.columns:
    if c.lower() in PROBLEM_COL_CANDIDATES:
        problem_col = c
        break
if problem_col is None:
    problem_col = df.columns[0]  # fallback: first column

problems = df[problem_col].dropna().drop_duplicates().astype(str).tolist()

# --------------------------
# Step 2: Save all problems into PDF
# --------------------------
def make_pdf(prompts, pdf_file):
    c = canvas.Canvas(pdf_file, pagesize=A4)
    width, height = A4
    c.setFont(FONT, FONT_SIZE)
    for i, prompt in enumerate(prompts, start=1):
        header = f"Problem {i}/{len(prompts)}"
        c.drawString(PAGE_MARGIN, height - PAGE_MARGIN, header)

        wrapped = textwrap.wrap(prompt, MAX_LINE_CHARS)
        y = height - PAGE_MARGIN - 20
        for line in wrapped:
            if y < PAGE_MARGIN + 20:
                c.showPage()
                c.setFont(FONT, FONT_SIZE)
                y = height - PAGE_MARGIN
            c.drawString(PAGE_MARGIN, y, line)
            y -= FONT_SIZE + 3
        c.showPage()
    c.save()

make_pdf(problems, PDF_FILE)

# --------------------------
# Step 3: Extract problems from PDF
# --------------------------
def extract_pdf(pdf_file):
    reader = PdfReader(pdf_file)
    texts = []
    for page in reader.pages:
        txt = page.extract_text() or ""
        lines = [ln.strip() for ln in txt.splitlines() if ln.strip()]
        # remove headers like "Problem X/Y"
        lines = [ln for ln in lines if not (ln.lower().startswith("problem ") and "/" in ln)]
        if lines:
            texts.append(" ".join(lines))
    return texts

extracted = extract_pdf(PDF_FILE)

# --------------------------
# Step 4: Wrap each in PromptML and save to TXT
# --------------------------
def make_promptml(problem_text):
    safe = problem_text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f"""
<PromptML>
  <Instruction>
    Generate PySpark code to efficiently solve the following problem statement:
  </Instruction>
  <ProblemStatement>
    {safe}
  </ProblemStatement>
  <Requirements>
    <Requirement>Automatically handle the core challenges of this problem.</Requirement>
    <Requirement>Be optimized for large-scale datasets where applicable.</Requirement>
    <Requirement>Output only PySpark code without extra explanation.</Requirement>
  </Requirements>
  <OutputFormat>
    <Type>PySpark Code</Type>
    <Language>Python</Language>
  </OutputFormat>
  <Constraints>
    <Constraint>No extra text outside code.</Constraint>
    <Constraint>Code must run in Spark environment.</Constraint>
  </Constraints>
</PromptML>
""".strip()

for idx, prob in enumerate(extracted, start=1):
    content = []
    content.append("PROBLEM STATEMENT\n")
    content.append(prob + "\n\n")
    content.append("PROMPT ML\n")
    content.append(make_promptml(prob))
    fname = os.path.join(TXT_DIR, f"problem_{idx:04d}.txt")
    with open(fname, "w", encoding="utf-8") as f:
        f.write("\n".join(content))

print(f"✅ Processed {len(extracted)} problems")
print(f"📄 PDF saved at: {PDF_FILE}")
print(f"📂 PromptML txt files saved in: {TXT_DIR}")
